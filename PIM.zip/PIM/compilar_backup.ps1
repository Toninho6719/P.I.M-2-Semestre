# Script para compilar o sistema de backup C++

Write-Host "================================" -ForegroundColor Cyan
Write-Host "  COMPILADOR DE BACKUP SYSTEM" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Verifica se o arquivo CPP existe
if (-not (Test-Path "backup_system.cpp")) {
    Write-Host "[ERRO] Arquivo backup_system.cpp não encontrado!" -ForegroundColor Red
    Write-Host "Certifique-se de estar no diretório correto." -ForegroundColor Yellow
    pause
    exit 1
}

Write-Host "[INFO] Arquivo backup_system.cpp encontrado." -ForegroundColor Green
Write-Host ""

# Tenta encontrar g++
Write-Host "[INFO] Procurando compilador g++..." -ForegroundColor Cyan

$gppPath = Get-Command g++ -ErrorAction SilentlyContinue

if ($null -eq $gppPath) {
    Write-Host "[AVISO] g++ não encontrado no PATH!" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Para instalar o MinGW (que inclui g++):" -ForegroundColor Yellow
    Write-Host "1. Baixe: https://sourceforge.net/projects/mingw-w64/" -ForegroundColor White
    Write-Host "2. Instale e adicione ao PATH" -ForegroundColor White
    Write-Host ""
    Write-Host "Ou use o Visual Studio com MSVC." -ForegroundColor White
    Write-Host ""
    pause
    exit 1
}

Write-Host "[OK] g++ encontrado: $($gppPath.Source)" -ForegroundColor Green
Write-Host ""

# Compila o programa
Write-Host "[INFO] Compilando backup_system.cpp..." -ForegroundColor Cyan
Write-Host ""

try {
    $processo = Start-Process -FilePath "g++" `
                              -ArgumentList "backup_system.cpp", "-o", "backup_system.exe", "-std=c++17" `
                              -NoNewWindow `
                              -Wait `
                              -PassThru `
                              -RedirectStandardError "compile_errors.txt"
    
    if ($processo.ExitCode -eq 0) {
        Write-Host "[SUCESSO] Compilação concluída!" -ForegroundColor Green
        Write-Host ""
        
        if (Test-Path "backup_system.exe") {
            Write-Host "[OK] Executável criado: backup_system.exe" -ForegroundColor Green
            Write-Host ""
            Write-Host "Você pode agora:" -ForegroundColor Cyan
            Write-Host "  1. Executar: .\backup_system.exe" -ForegroundColor White
            Write-Host "  2. Usar via Python: python testar_backup.py" -ForegroundColor White
            Write-Host "  3. Integrar com a GUI do sistema" -ForegroundColor White
        }
    } else {
        Write-Host "[ERRO] Falha na compilação!" -ForegroundColor Red
        
        if (Test-Path "compile_errors.txt") {
            Write-Host ""
            Write-Host "Erros de compilação:" -ForegroundColor Yellow
            Get-Content "compile_errors.txt" | Write-Host -ForegroundColor Red
        }
    }
} catch {
    Write-Host "[ERRO] Exceção durante compilação: $_" -ForegroundColor Red
}

Write-Host ""
pause
