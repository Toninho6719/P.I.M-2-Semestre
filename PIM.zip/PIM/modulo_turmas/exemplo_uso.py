"""
Exemplo de Uso do Módulo de Turmas

Este arquivo demonstra como usar as funcionalidades do módulo de turmas
de forma independente ou integrada ao sistema principal.
"""

# ===== MODO 1: USO INDEPENDENTE (APENAS DATABASE LOCAL) =====

from modulo_turmas.turma_model import Turma
from modulo_turmas.turma_database import (
    salvar_turma,
    listar_turmas,
    buscar_turma_por_id,
    adicionar_aluno_a_turma,
    contar_alunos_por_turma,
    listar_alunos_da_turma
)

# Criar nova turma
print("=== Criando Nova Turma ===")
turma1 = Turma(id="1", nome_disciplina="Matemática I", id_alunos=["1", "2", "3"])
salvar_turma(turma1)
print(f"Turma criada: {turma1}")

# Listar todas as turmas
print("\n=== Listando Todas as Turmas ===")
turmas = listar_turmas()
for turma in turmas:
    print(turma)

# Buscar turma específica
print("\n=== Buscando Turma por ID ===")
turma = buscar_turma_por_id("1")
if turma:
    print(f"Turma encontrada: {turma}")
    print(f"Quantidade de alunos: {turma.quantidade_alunos()}")

# Adicionar aluno à turma
print("\n=== Adicionando Aluno à Turma ===")
adicionar_aluno_a_turma(id_aluno="4", id_turma="1")
turma_atualizada = buscar_turma_por_id("1")
print(f"Turma após adicionar aluno: {turma_atualizada}")

# Verificar se aluno está na turma
print("\n=== Verificando Aluno na Turma ===")
if turma_atualizada.tem_aluno("4"):
    print("Aluno 4 está na turma!")

# Contar alunos
print("\n=== Contando Alunos ===")
total = contar_alunos_por_turma("1")
print(f"Total de alunos na turma 1: {total}")

# Listar IDs dos alunos
print("\n=== Listando IDs dos Alunos ===")
ids_alunos = listar_alunos_da_turma("1")
print(f"IDs dos alunos: {ids_alunos}")


# ===== MODO 2: INTEGRAÇÃO COM DATA SERVICE =====

"""
Para usar com o DataService (modo LOCAL ou REDE):

from data_service import DataService

# Inicializar serviço
data = DataService()

# Listar turmas
turmas = data.listar_turmas()
for t in turmas:
    print(t)

# Buscar turma
turma = data.buscar_turma_por_id("1")
if turma:
    print(turma)

# Salvar turma
nova_turma = Turma(id="2", nome_disciplina="Português", id_alunos=[])
data.salvar_turma(nova_turma)

# Adicionar aluno à turma
data.adicionar_aluno_a_turma(id_aluno="5", id_turma="2")
data.atualizar_turma_aluno(id_aluno="5", id_turma="2")
"""


# ===== MODO 3: USO NA INTERFACE GRÁFICA =====

"""
Para integrar à interface gráfica (gui_system.py):

1. Importe as funções do turma_gui.py
2. Adicione ao seu AcademicGUI:

from modulo_turmas import turma_gui

class AcademicGUI:
    def __init__(self, root, data_service):
        self.root = root
        self.data = data_service
        # ... resto da inicialização
    
    # Copie os métodos de turma_gui.py como métodos da classe:
    criar_aba_turmas_adm = turma_gui.criar_aba_turmas_adm
    listar_turmas_table = turma_gui.listar_turmas_table
    cadastrar_turma = turma_gui.cadastrar_turma
    adicionar_aluno_turma = turma_gui.adicionar_aluno_turma
"""


# ===== MODO 4: MÉTODOS ÚTEIS DA CLASSE TURMA =====

print("\n=== Métodos da Classe Turma ===")
turma_exemplo = Turma(id="100", nome_disciplina="Física", id_alunos=["10", "20"])

# Adicionar aluno
turma_exemplo.adicionar_aluno("30")
print(f"Após adicionar aluno 30: {turma_exemplo.id_alunos}")

# Remover aluno
turma_exemplo.remover_aluno("20")
print(f"Após remover aluno 20: {turma_exemplo.id_alunos}")

# Verificar se tem aluno
print(f"Tem aluno 10? {turma_exemplo.tem_aluno('10')}")
print(f"Tem aluno 99? {turma_exemplo.tem_aluno('99')}")

# Quantidade
print(f"Quantidade de alunos: {turma_exemplo.quantidade_alunos()}")

# String representation
print(f"Turma: {turma_exemplo}")


# ===== ESTRUTURA DO ARQUIVO turmas.txt =====

"""
Formato do arquivo database/turmas.txt:

id;nome_disciplina;id_aluno1,id_aluno2,id_aluno3

Exemplo:
1;Matemática I;1,2,3,5
2;Português;4,6,7
3;História;2,8,9
4;Física;
5;Química;1,3,5,7,9,11

Observações:
- Cada linha representa uma turma
- Campos separados por ponto e vírgula (;)
- IDs dos alunos separados por vírgula (,)
- Turma sem alunos tem campo vazio após segundo ;
"""
