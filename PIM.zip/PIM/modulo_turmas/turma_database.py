"""
Funções de Banco de Dados para Turmas
Extraído de database.py
"""

import os
from modulo_turmas.turma_model import Turma

# Caminho para o arquivo de turmas
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_DIR = os.path.join(BASE_DIR, 'database')
ARQUIVO_TURMAS = os.path.join(DATABASE_DIR, 'turmas.txt')
ARQUIVO_ALUNOS = os.path.join(DATABASE_DIR, 'alunos.txt')


def _reescrever_arquivo(arquivo, linhas_novas):
    """Função auxiliar para reescrever arquivo"""
    with open(arquivo, 'w', encoding='utf-8') as f:
        f.writelines(linhas_novas)


# --- Funções de Turma ---

def salvar_turma(turma):
    """
    Salva uma turma no arquivo turmas.txt
    
    Args:
        turma (Turma): Objeto Turma a ser salvo
    """
    ids_alunos_str = ",".join(map(str, turma.id_alunos))
    with open(ARQUIVO_TURMAS, 'a', encoding='utf-8') as f:
        f.write(f"{turma.id};{turma.nome_disciplina};{ids_alunos_str}\n")


def listar_turmas():
    """
    Lista todas as turmas cadastradas
    
    Returns:
        list: Lista de objetos Turma
    """
    turmas = []
    try:
        with open(ARQUIVO_TURMAS, 'r', encoding='utf-8') as f:
            for linha in f:
                partes = linha.strip().split(';')
                if len(partes) >= 2:
                    id, nome = partes[0], partes[1]
                    ids_alunos = partes[2].split(',') if len(partes) > 2 and partes[2] else []
                    turmas.append(Turma(id=id, nome_disciplina=nome, id_alunos=[i for i in ids_alunos if i]))
        return turmas
    except FileNotFoundError:
        return []


def buscar_turma_por_id(id_turma):
    """
    Busca uma turma específica por ID
    
    Args:
        id_turma (str): ID da turma
        
    Returns:
        Turma: Objeto Turma ou None se não encontrado
    """
    for turma in listar_turmas():
        if turma.id == str(id_turma):
            return turma
    return None


def adicionar_aluno_a_turma(id_aluno, id_turma):
    """
    Adiciona um aluno a uma turma existente
    
    Args:
        id_aluno (str): ID do aluno
        id_turma (str): ID da turma
    """
    id_turma_str = str(id_turma)
    id_aluno_str = str(id_aluno)

    turmas = listar_turmas()
    linhas_novas = []
    for turma in turmas:
        if turma.id == id_turma_str:
            if id_aluno_str not in [str(x) for x in turma.id_alunos]:
                turma.id_alunos.append(id_aluno_str)
        ids_alunos_str = ",".join(map(str, turma.id_alunos))
        linhas_novas.append(f"{turma.id};{turma.nome_disciplina};{ids_alunos_str}\n")
    _reescrever_arquivo(ARQUIVO_TURMAS, linhas_novas)


def atualizar_turma_aluno(id_aluno, id_turma):
    """
    Atualiza a turma de um aluno no arquivo de alunos
    
    Args:
        id_aluno (str): ID do aluno
        id_turma (str): ID da nova turma
    """
    # Importa função necessária do database principal
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import database as db
    
    id_aluno_str = str(id_aluno)
    id_turma_str = str(id_turma)

    alunos = db.listar_alunos(filter_ativos=False)
    linhas_novas = []
    for aluno in alunos:
        if str(aluno.id) == id_aluno_str:
            aluno.id_turma = id_turma_str
        id_turma_write = aluno.id_turma if aluno.id_turma else ''
        linhas_novas.append(f"{aluno.id};{aluno.nome};{aluno.ra};{id_turma_write}\n")
    _reescrever_arquivo(ARQUIVO_ALUNOS, linhas_novas)


def atualizar_turma_alunos(ids_alunos, id_turma):
    """
    Atualiza a turma de múltiplos alunos
    
    Args:
        ids_alunos (list): Lista de IDs dos alunos
        id_turma (str): ID da turma
    """
    for id_aluno in ids_alunos:
        atualizar_turma_aluno(id_aluno, id_turma)


def remover_aluno_da_turma(id_aluno, id_turma):
    """
    Remove um aluno de uma turma específica
    
    Args:
        id_aluno (str): ID do aluno
        id_turma (str): ID da turma
    """
    id_turma_str = str(id_turma)
    id_aluno_str = str(id_aluno)

    turmas = listar_turmas()
    linhas_novas = []
    for turma in turmas:
        if turma.id == id_turma_str:
            if id_aluno_str in turma.id_alunos:
                turma.id_alunos.remove(id_aluno_str)
        ids_alunos_str = ",".join(map(str, turma.id_alunos))
        linhas_novas.append(f"{turma.id};{turma.nome_disciplina};{ids_alunos_str}\n")
    _reescrever_arquivo(ARQUIVO_TURMAS, linhas_novas)


def contar_alunos_por_turma(id_turma):
    """
    Conta quantos alunos estão em uma turma
    
    Args:
        id_turma (str): ID da turma
        
    Returns:
        int: Quantidade de alunos na turma
    """
    turma = buscar_turma_por_id(id_turma)
    if turma:
        return len(turma.id_alunos)
    return 0


def listar_alunos_da_turma(id_turma):
    """
    Lista todos os IDs dos alunos de uma turma
    
    Args:
        id_turma (str): ID da turma
        
    Returns:
        list: Lista de IDs dos alunos
    """
    turma = buscar_turma_por_id(id_turma)
    if turma:
        return turma.id_alunos
    return []
