# Módulo de Turmas

Este módulo contém todos os arquivos relacionados ao gerenciamento de **Turmas** no sistema acadêmico PIM.

## Estrutura de Arquivos

### 1. **turma_model.py**
Modelo de dados da classe `Turma`, extraído de `models.py`.

### 2. **turma_database.py**
Funções de banco de dados para manipulação de turmas:
- `salvar_turma()` - Salva turma no arquivo
- `listar_turmas()` - Lista todas as turmas
- `buscar_turma_por_id()` - Busca turma específica
- `adicionar_aluno_a_turma()` - Adiciona aluno em turma
- `atualizar_turma_aluno()` - Atualiza turma do aluno
- `atualizar_turma_alunos()` - Atualiza turma de múltiplos alunos

### 3. **turma_data_service.py**
Camada de abstração que decide entre modo LOCAL ou REDE para operações de turmas.

### 4. **turma_gui.py**
Interface gráfica para gerenciamento de turmas:
- Cadastrar nova turma
- Adicionar aluno à turma
- Listar turmas em tabela
- Visualizar alunos por turma

### 5. **turma_client.py**
Métodos do cliente de rede relacionados a turmas (extraído de `client_proxy.py`):
- `listar_turmas()`
- `cadastrar_turma()`
- `buscar_turma()`

### 6. **turma_server.py**
Handlers do servidor para operações de turmas (extraído de `server_proxy.py`):
- `handle_listar_turmas()`
- `handle_cadastrar_turma()`
- `handle_buscar_turma()`

## Dependências

- **models.py**: Classe Aluno (relacionamento)
- **database.py**: Arquivo de dados `turmas.txt`
- **data_service.py**: Integração com sistema principal

## Uso

```python
from modulo_turmas.turma_model import Turma
from modulo_turmas.turma_database import listar_turmas, salvar_turma

# Criar nova turma
turma = Turma(id="1", nome_disciplina="Matemática", id_alunos=["1", "2", "3"])
salvar_turma(turma)

# Listar turmas
turmas = listar_turmas()
for t in turmas:
    print(t)
```

## Arquivo de Dados

**Localização**: `database/turmas.txt`

**Formato**: `id;nome_disciplina;id_aluno1,id_aluno2,id_aluno3`

**Exemplo**:
```
1;Matemática I;1,2,3,5
2;Português;4,6,7
3;História;2,8,9
```
