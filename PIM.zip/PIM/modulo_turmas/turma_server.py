"""
Handlers do Servidor para Turmas
Extraído de server_proxy.py

Estes handlers devem ser integrados à classe AcademicServer
"""

import database as db
from models import Turma


def handle_listar_turmas(self, data):
    """
    Handler: Lista turmas
    
    Args:
        data (dict): Dados da requisição
        
    Returns:
        dict: Resposta com lista de turmas
    """
    turmas = db.listar_turmas()
    turmas_list = [
        {
            'id': t.id,
            'nome_disciplina': t.nome_disciplina,
            'id_alunos': t.id_alunos
        }
        for t in turmas
    ]
    return {'status': 'success', 'data': turmas_list}


def handle_cadastrar_turma(self, data):
    """
    Handler: Cadastra turma
    
    Args:
        data (dict): Dados da turma
        
    Returns:
        dict: Resposta de sucesso ou erro
    """
    print(f"🖥️  [SERVER] Cadastrando turma: {data.get('nome_disciplina')}")
    id_turma = db.get_proximo_id(db.ARQUIVO_TURMAS)
    turma = Turma(
        id=id_turma,
        nome_disciplina=data['nome_disciplina'],
        id_alunos=data.get('id_alunos', [])
    )
    db.salvar_turma(turma)
    print(f"🖥️  [SERVER] Turma {data.get('nome_disciplina')} salva com ID {id_turma}")
    return {'status': 'success', 'message': 'Turma cadastrada', 'id': id_turma}


def handle_buscar_turma(self, data):
    """
    Handler: Busca turma por ID
    
    Args:
        data (dict): Contém id_turma
        
    Returns:
        dict: Dados da turma ou erro
    """
    turma = db.buscar_turma_por_id(data['id_turma'])
    if turma:
        return {
            'status': 'success',
            'data': {
                'id': turma.id,
                'nome_disciplina': turma.nome_disciplina,
                'id_alunos': turma.id_alunos
            }
        }
    return {'status': 'error', 'message': 'Turma não encontrada'}


# === INSTRUÇÕES DE INTEGRAÇÃO ===
#
# Para integrar ao server_proxy.py:
#
# 1. Copie as funções acima
# 2. Cole dentro da classe AcademicServer
# 3. Adicione os handlers ao dicionário de handlers no método handle_client:
#
#    handlers = {
#        ...
#        'listar_turmas': self.handle_listar_turmas,
#        'cadastrar_turma': self.handle_cadastrar_turma,
#        'buscar_turma': self.handle_buscar_turma,
#        ...
#    }
