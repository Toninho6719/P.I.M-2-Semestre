"""
Interface Gráfica para Gerenciamento de Turmas
Extraído de gui_system.py

Funções de interface para cadastro e gerenciamento de turmas
"""

import tkinter as tk
from tkinter import ttk, messagebox
from models import Turma


def criar_aba_turmas_adm(self, parent):
    """
    Cria a aba de gerenciamento de turmas na interface administrativa
    
    Args:
        self: Instância da classe AcademicGUI
        parent: Widget pai (Frame ou Notebook)
    """
    # Frame de botões
    btn_frame = tk.Frame(parent, bg=self.colors['white'])
    btn_frame.pack(fill='x', padx=10, pady=10)
    
    tk.Button(btn_frame, text="Cadastrar Turma",
             bg=self.colors['accent'], fg=self.colors['white'],
             font=('Segoe UI', 10), relief='flat', cursor='hand2',
             command=self.cadastrar_turma).pack(side='left', padx=5, ipady=5, ipadx=10)
    
    tk.Button(btn_frame, text="Adicionar Aluno à Turma",
             bg=self.colors['accent'], fg=self.colors['white'],
             font=('Segoe UI', 10), relief='flat', cursor='hand2',
             command=self.adicionar_aluno_turma).pack(side='left', padx=5, ipady=5, ipadx=10)
    
    tk.Button(btn_frame, text="Atualizar Lista",
             bg=self.colors['success'], fg=self.colors['white'],
             font=('Segoe UI', 10), relief='flat', cursor='hand2',
             command=lambda: self.listar_turmas_table()).pack(side='right', padx=5, ipady=5, ipadx=10)
    
    # Frame para a tabela
    table_frame = tk.Frame(parent, bg=self.colors['white'])
    table_frame.pack(fill='both', expand=True, padx=10, pady=10)
    
    # Scrollbar
    scrollbar = tk.Scrollbar(table_frame)
    scrollbar.pack(side='right', fill='y')
    
    # Treeview
    self.turmas_tree = ttk.Treeview(table_frame,
                                   columns=('ID', 'Nome', 'Qtd Alunos', 'Alunos'),
                                   show='headings',
                                   yscrollcommand=scrollbar.set)
    
    self.turmas_tree.heading('ID', text='ID')
    self.turmas_tree.heading('Nome', text='Nome da Turma')
    self.turmas_tree.heading('Qtd Alunos', text='Qtd Alunos')
    self.turmas_tree.heading('Alunos', text='Alunos')
    
    self.turmas_tree.column('ID', width=50)
    self.turmas_tree.column('Nome', width=150)
    self.turmas_tree.column('Qtd Alunos', width=100)
    self.turmas_tree.column('Alunos', width=400)
    
    scrollbar.config(command=self.turmas_tree.yview)
    self.turmas_tree.pack(fill='both', expand=True)
    
    self.listar_turmas_table()


def listar_turmas_table(self):
    """
    Carrega turmas na tabela de visualização
    
    Args:
        self: Instância da classe AcademicGUI
    """
    for item in self.turmas_tree.get_children():
        self.turmas_tree.delete(item)
    
    turmas = self.data.listar_turmas()
    todos_alunos = {al.id: al for al in self.data.listar_alunos(filter_ativos=False)}
    
    for turma in turmas:
        qtd = len(turma.id_alunos)
        alunos_nomes = []
        for id_aluno in turma.id_alunos:
            if id_aluno in todos_alunos:
                alunos_nomes.append(todos_alunos[id_aluno].nome)
        
        alunos_str = ", ".join(alunos_nomes) if alunos_nomes else "Nenhum aluno"
        self.turmas_tree.insert('', 'end', values=(turma.id, turma.nome_disciplina, qtd, alunos_str))


def cadastrar_turma(self):
    """
    Janela para cadastrar nova turma
    
    Args:
        self: Instância da classe AcademicGUI
    """
    janela = tk.Toplevel(self.root)
    janela.title("Cadastrar Nova Turma")
    janela.geometry("500x400")
    janela.resizable(False, False)
    janela.grab_set()
    
    frame = tk.Frame(janela, bg=self.colors['white'])
    frame.pack(fill='both', expand=True, padx=20, pady=20)
    
    tk.Label(frame, text="Nome da Turma:", bg=self.colors['white'],
            font=('Segoe UI', 10)).pack(pady=5)
    nome_entry = tk.Entry(frame, font=('Segoe UI', 10), width=40)
    nome_entry.pack(pady=5)
    nome_entry.focus()
    
    tk.Label(frame, text="Alunos disponíveis (sem turma):", bg=self.colors['white'],
            font=('Segoe UI', 10)).pack(pady=10)
    
    # Listbox para selecionar alunos
    list_frame = tk.Frame(frame, bg=self.colors['white'])
    list_frame.pack(fill='both', expand=True, pady=5)
    
    scrollbar = tk.Scrollbar(list_frame)
    scrollbar.pack(side='right', fill='y')
    
    alunos_listbox = tk.Listbox(list_frame, selectmode='multiple',
                                font=('Segoe UI', 9),
                                yscrollcommand=scrollbar.set)
    alunos_listbox.pack(side='left', fill='both', expand=True)
    scrollbar.config(command=alunos_listbox.yview)
    
    # Carregar alunos sem turma
    alunos_disponiveis = self.data.listar_alunos_sem_turma()
    for aluno in alunos_disponiveis:
        alunos_listbox.insert('end', f"{aluno.id} - {aluno.nome} (RA: {aluno.ra})")
    
    def salvar():
        nome_turma = nome_entry.get().strip()
        if not nome_turma:
            messagebox.showwarning("Campo vazio", "Digite o nome da turma!", parent=janela)
            return
        
        # Pegar IDs dos alunos selecionados
        indices_selecionados = alunos_listbox.curselection()
        ids_alunos = []
        for idx in indices_selecionados:
            texto = alunos_listbox.get(idx)
            id_aluno = texto.split(' - ')[0]
            ids_alunos.append(id_aluno)
        
        # Criar turma
        novo_id = str(self.data.get_proximo_id(self.data.ARQUIVO_TURMAS))
        turma = Turma(id=novo_id, nome_disciplina=nome_turma, id_alunos=ids_alunos)
        self.data.salvar_turma(turma)
        
        # Atualizar alunos
        if ids_alunos:
            self.data.atualizar_turma_alunos(ids_alunos, novo_id)
        
        messagebox.showinfo("Sucesso", f"Turma '{nome_turma}' cadastrada com {len(ids_alunos)} aluno(s)!", parent=janela)
        janela.destroy()
        self.listar_turmas_table()
    
    tk.Button(frame, text="Salvar Turma", bg=self.colors['success'],
             fg=self.colors['white'], font=('Segoe UI', 10, 'bold'),
             relief='flat', cursor='hand2',
             command=salvar).pack(pady=15, ipadx=20, ipady=5)


def adicionar_aluno_turma(self):
    """
    Adiciona um aluno existente a uma turma
    
    Args:
        self: Instância da classe AcademicGUI
    """
    janela = tk.Toplevel(self.root)
    janela.title("Adicionar Aluno à Turma")
    janela.geometry("400x250")
    janela.resizable(False, False)
    janela.grab_set()
    
    frame = tk.Frame(janela, bg=self.colors['white'])
    frame.pack(fill='both', expand=True, padx=20, pady=20)
    
    # Selecionar aluno
    tk.Label(frame, text="Selecione o Aluno:", bg=self.colors['white'],
            font=('Segoe UI', 10)).pack(pady=5)
    
    alunos_disponiveis = self.data.listar_alunos_sem_turma()
    if not alunos_disponiveis:
        tk.Label(frame, text="Nenhum aluno disponível sem turma.",
                bg=self.colors['white'], fg=self.colors['danger'],
                font=('Segoe UI', 10)).pack(pady=20)
        return
    
    alunos_opcoes = [f"{a.id} - {a.nome} (RA: {a.ra})" for a in alunos_disponiveis]
    aluno_combo = ttk.Combobox(frame, values=alunos_opcoes,
                              font=('Segoe UI', 9), width=35, state='readonly')
    aluno_combo.pack(pady=5)
    
    # Selecionar turma
    tk.Label(frame, text="Selecione a Turma:", bg=self.colors['white'],
            font=('Segoe UI', 10)).pack(pady=5)
    
    turmas = self.data.listar_turmas()
    if not turmas:
        tk.Label(frame, text="Nenhuma turma cadastrada.",
                bg=self.colors['white'], fg=self.colors['danger'],
                font=('Segoe UI', 10)).pack(pady=20)
        return
    
    turmas_opcoes = [f"{t.id} - {t.nome_disciplina}" for t in turmas]
    turma_combo = ttk.Combobox(frame, values=turmas_opcoes,
                              font=('Segoe UI', 9), width=35, state='readonly')
    turma_combo.pack(pady=5)
    
    def adicionar():
        if not aluno_combo.get() or not turma_combo.get():
            messagebox.showwarning("Seleção incompleta", "Selecione aluno e turma!", parent=janela)
            return
        
        id_aluno = aluno_combo.get().split(' - ')[0]
        id_turma = turma_combo.get().split(' - ')[0]
        
        self.data.atualizar_turma_aluno(id_aluno, id_turma)
        self.data.adicionar_aluno_a_turma(id_aluno, id_turma)
        
        messagebox.showinfo("Sucesso", "Aluno adicionado à turma com sucesso!", parent=janela)
        janela.destroy()
        self.listar_turmas_table()
    
    tk.Button(frame, text="Adicionar", bg=self.colors['success'],
             fg=self.colors['white'], font=('Segoe UI', 10, 'bold'),
             relief='flat', cursor='hand2',
             command=adicionar).pack(pady=15, ipadx=30, ipady=5)


# === INSTRUÇÕES DE INTEGRAÇÃO ===
#
# Para integrar ao gui_system.py:
#
# 1. Copie as funções acima
# 2. Cole dentro da classe AcademicGUI
# 3. Mantenha a indentação correta (todas devem ser métodos da classe)
# 4. A função criar_aba_turmas_adm() é chamada pela interface principal
# 5. Certifique-se de que self.colors e self.data estão definidos
