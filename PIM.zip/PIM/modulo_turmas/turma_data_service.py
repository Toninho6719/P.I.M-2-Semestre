"""
Camada de Abstração do Data Service para Turmas
Extraído de data_service.py

Métodos que decidem entre modo LOCAL ou REDE para operações de turmas
"""


def listar_turmas(self):
    """
    Lista turmas (modo LOCAL ou REDE)
    
    Returns:
        list: Lista de objetos Turma
    """
    if self.modo_rede:
        from models import Turma
        turmas_dict = self.network_client.listar_turmas()
        return [Turma(id=t['id'], nome_disciplina=t['nome_disciplina'], 
                     id_alunos=t['id_alunos']) for t in turmas_dict]
    else:
        return self.db.listar_turmas()


def buscar_turma_por_id(self, id_turma):
    """
    Busca turma por ID (modo LOCAL ou REDE)
    
    Args:
        id_turma (str): ID da turma
        
    Returns:
        Turma: Objeto Turma ou None
    """
    if self.modo_rede:
        from models import Turma
        turma_dict = self.network_client.buscar_turma(id_turma)
        if turma_dict:
            return Turma(id=turma_dict['id'], 
                       nome_disciplina=turma_dict['nome_disciplina'],
                       id_alunos=turma_dict['id_alunos'])
        return None
    else:
        return self.db.buscar_turma_por_id(id_turma)


def salvar_turma(self, turma):
    """
    Salva turma (modo LOCAL ou REDE)
    
    Args:
        turma (Turma): Objeto Turma
        
    Returns:
        bool: True se sucesso
    """
    if self.modo_rede:
        success, msg = self.network_client.cadastrar_turma(
            id=turma.id, nome_disciplina=turma.nome_disciplina,
            id_alunos=turma.id_alunos
        )
        return success
    else:
        self.db.salvar_turma(turma)
        return True


def adicionar_aluno_a_turma(self, id_aluno, id_turma):
    """
    Adiciona aluno a uma turma (modo LOCAL ou REDE)
    
    Args:
        id_aluno (str): ID do aluno
        id_turma (str): ID da turma
        
    Returns:
        bool: True se sucesso
    """
    if self.modo_rede:
        # Modo rede: atualiza via servidor
        # Recarrega turma, adiciona aluno, salva
        turma = self.buscar_turma_por_id(id_turma)
        if turma and str(id_aluno) not in turma.id_alunos:
            turma.id_alunos.append(str(id_aluno))
            return self.salvar_turma(turma)
        return True
    else:
        self.db.adicionar_aluno_a_turma(id_aluno, id_turma)
        return True


def atualizar_turma_aluno(self, id_aluno, id_turma):
    """
    Atualiza turma de um aluno (modo LOCAL ou REDE)
    
    Args:
        id_aluno (str): ID do aluno
        id_turma (str): ID da turma
        
    Returns:
        bool: True se sucesso
    """
    if self.modo_rede:
        # Busca aluno, atualiza turma, salva
        aluno = self.buscar_aluno_por_id(id_aluno)
        if aluno:
            aluno.id_turma = id_turma
            return self.salvar_aluno(aluno)
        return False
    else:
        self.db.atualizar_turma_aluno(id_aluno, id_turma)
        return True


def atualizar_turma_alunos(self, ids_alunos, id_turma):
    """
    Atualiza turma de múltiplos alunos (modo LOCAL ou REDE)
    
    Args:
        ids_alunos (list): Lista de IDs dos alunos
        id_turma (str): ID da turma
        
    Returns:
        bool: True se sucesso
    """
    if self.modo_rede:
        for id_aluno in ids_alunos:
            self.atualizar_turma_aluno(id_aluno, id_turma)
        return True
    else:
        self.db.atualizar_turma_alunos(ids_alunos, id_turma)
        return True


@property
def ARQUIVO_TURMAS(self):
    """Propriedade para compatibilidade com código legado"""
    return self.db.ARQUIVO_TURMAS if not self.modo_rede else None


# === INSTRUÇÕES DE INTEGRAÇÃO ===
#
# Para integrar ao data_service.py:
#
# 1. Copie as funções acima
# 2. Cole dentro da classe DataService
# 3. Mantenha a indentação correta
# 4. Os métodos já verificam self.modo_rede automaticamente
