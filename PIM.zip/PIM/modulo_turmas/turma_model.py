"""
Modelo de Dados: Turma
Extraído de models.py
"""

class Turma:
    """
    Classe que representa uma Turma no sistema acadêmico.
    
    Atributos:
        id (str): Identificador único da turma
        nome_disciplina (str): Nome da disciplina/turma
        id_alunos (list): Lista de IDs dos alunos matriculados
    """
    
    def __init__(self, id, nome_disciplina, id_alunos=None):
        self.id = str(id)
        self.nome_disciplina = nome_disciplina
        self.id_alunos = id_alunos if id_alunos is not None else []

    def __str__(self):
        num_alunos = len(self.id_alunos)
        return f"ID: {self.id}, Turma: {self.nome_disciplina}, Alunos: {num_alunos}"
    
    def adicionar_aluno(self, id_aluno):
        """Adiciona um aluno à turma se ainda não estiver presente"""
        id_aluno_str = str(id_aluno)
        if id_aluno_str not in self.id_alunos:
            self.id_alunos.append(id_aluno_str)
            return True
        return False
    
    def remover_aluno(self, id_aluno):
        """Remove um aluno da turma"""
        id_aluno_str = str(id_aluno)
        if id_aluno_str in self.id_alunos:
            self.id_alunos.remove(id_aluno_str)
            return True
        return False
    
    def quantidade_alunos(self):
        """Retorna a quantidade de alunos na turma"""
        return len(self.id_alunos)
    
    def tem_aluno(self, id_aluno):
        """Verifica se um aluno está na turma"""
        return str(id_aluno) in self.id_alunos
