"""
Módulo de Turmas - Sistema Acadêmico PIM

Este módulo contém todas as funcionalidades relacionadas ao gerenciamento de turmas.
"""

from .turma_model import Turma

__all__ = ['Turma']
__version__ = '1.0.0'
__author__ = 'Sistema Acadêmico PIM'
