"""
Métodos do Cliente de Rede para Turmas
Extraído de client_proxy.py

Estes métodos devem ser integrados à classe AcademicClient
"""


def listar_turmas(self):
    """
    Lista turmas via rede
    
    Returns:
        list: Lista de dicionários com dados das turmas
    """
    response = self.send_request('listar_turmas')
    if response.get('status') == 'success':
        return response.get('data', [])
    return []


def cadastrar_turma(self, id, nome_disciplina, id_alunos=None):
    """
    Cadastra turma via rede
    
    Args:
        id (str): ID da turma
        nome_disciplina (str): Nome da disciplina
        id_alunos (list): Lista de IDs dos alunos
        
    Returns:
        tuple: (success, message)
    """
    response = self.send_request('cadastrar_turma', {
        'id': id,
        'nome_disciplina': nome_disciplina,
        'id_alunos': id_alunos or []
    })
    return response.get('status') == 'success', response.get('message', '')


def buscar_turma(self, id_turma):
    """
    Busca turma por ID via rede
    
    Args:
        id_turma (str): ID da turma
        
    Returns:
        dict: Dados da turma ou None
    """
    response = self.send_request('buscar_turma', {
        'id_turma': id_turma
    })
    if response.get('status') == 'success':
        return response.get('data')
    return None


# === INSTRUÇÕES DE INTEGRAÇÃO ===
# 
# Para integrar estes métodos ao client_proxy.py:
#
# 1. Copie as funções acima
# 2. Cole dentro da classe AcademicClient
# 3. Mantenha a indentação correta
# 4. Os métodos já estão prontos para uso com self.send_request()
