# Diagrama de Relacionamento - Módulo Turmas

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        SISTEMA ACADÊMICO PIM                            │
│                     Módulo de Turmas - Arquitetura                      │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                           CAMADA DE MODELO                              │
├─────────────────────────────────────────────────────────────────────────┤
│  turma_model.py                                                         │
│  ┌────────────────────────┐                                            │
│  │   class Turma:         │                                            │
│  │   - id                 │                                            │
│  │   - nome_disciplina    │                                            │
│  │   - id_alunos[]        │                                            │
│  │   + adicionar_aluno()  │                                            │
│  │   + remover_aluno()    │                                            │
│  │   + tem_aluno()        │                                            │
│  └────────────────────────┘                                            │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                      CAMADA DE ACESSO A DADOS                           │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────┐    ┌─────────────────────────────┐  │
│  │  turma_database.py          │    │  database/turmas.txt        │  │
│  │  (MODO LOCAL)               │───▶│  Formato: id;nome;alunos    │  │
│  │                             │    │  1;Matemática;1,2,3         │  │
│  │  + salvar_turma()           │    └─────────────────────────────┘  │
│  │  + listar_turmas()          │                                      │
│  │  + buscar_turma_por_id()    │                                      │
│  │  + adicionar_aluno_a_turma()│                                      │
│  │  + atualizar_turma_aluno()  │                                      │
│  └─────────────────────────────┘                                      │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                     CAMADA DE ABSTRAÇÃO (DATA SERVICE)                  │
├─────────────────────────────────────────────────────────────────────────┤
│  turma_data_service.py                                                  │
│                                                                         │
│       ┌───────────────┐                                                │
│       │ MODO_REDE?    │                                                │
│       └───────┬───────┘                                                │
│               │                                                         │
│       ┌───────┴───────┐                                                │
│       │               │                                                 │
│   [LOCAL]         [REDE]                                               │
│       ↓               ↓                                                 │
│  turma_database  turma_client ───▶ SERVIDOR ◀─── turma_server         │
│                                                                         │
│  Métodos:                                                              │
│  • listar_turmas()                                                     │
│  • buscar_turma_por_id()                                               │
│  • salvar_turma()                                                      │
│  • adicionar_aluno_a_turma()                                           │
│  • atualizar_turma_aluno()                                             │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                         CAMADA DE INTERFACE                             │
├─────────────────────────────────────────────────────────────────────────┤
│  turma_gui.py                                                           │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────┐     │
│  │  Aba Turmas (Administrador)                                  │     │
│  ├──────────────────────────────────────────────────────────────┤     │
│  │  [Cadastrar Turma] [Adicionar Aluno] [Atualizar Lista]      │     │
│  ├────┬─────────────────┬──────────────┬────────────────────────┤     │
│  │ ID │ Nome da Turma   │ Qtd Alunos   │ Alunos                │     │
│  ├────┼─────────────────┼──────────────┼────────────────────────┤     │
│  │ 1  │ Matemática I    │ 3            │ João, Maria, Pedro    │     │
│  │ 2  │ Português       │ 2            │ Ana, Carlos           │     │
│  │ 3  │ História        │ 4            │ Lucas, Julia, ...     │     │
│  └────┴─────────────────┴──────────────┴────────────────────────┘     │
│                                                                         │
│  Funções:                                                              │
│  • criar_aba_turmas_adm() - Cria interface                            │
│  • listar_turmas_table() - Popula tabela                              │
│  • cadastrar_turma() - Janela de cadastro                             │
│  • adicionar_aluno_turma() - Janela de adição                         │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                        COMUNICAÇÃO EM REDE                              │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CLIENTE (turma_client.py)         SERVIDOR (turma_server.py)         │
│  ┌─────────────────────┐           ┌──────────────────────────┐       │
│  │ listar_turmas()     │──────────▶│ handle_listar_turmas()   │       │
│  │ cadastrar_turma()   │──────────▶│ handle_cadastrar_turma() │       │
│  │ buscar_turma()      │──────────▶│ handle_buscar_turma()    │       │
│  └─────────────────────┘           └──────────────────────────┘       │
│           │                                     │                       │
│           │         JSON sobre Socket           │                       │
│           └────────────────────────────────────┘                       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      RELACIONAMENTOS COM OUTRAS ENTIDADES               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────┐      1:N      ┌──────────┐                              │
│  │  TURMA   │──────────────▶│  ALUNO   │                              │
│  │          │               │ id_turma │                              │
│  └────┬─────┘               └──────────┘                              │
│       │                                                                 │
│       │ 1:N                                                            │
│       │                                                                 │
│       ├────────────────────────────────┐                               │
│       │                                │                               │
│       ▼                                ▼                               │
│  ┌──────────┐                    ┌──────────────┐                     │
│  │  AULA    │                    │  ATIVIDADE   │                     │
│  │ id_turma │                    │  id_turma    │                     │
│  └──────────┘                    └──────────────┘                     │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                           FLUXO DE DADOS                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CADASTRO DE TURMA:                                                    │
│  GUI → DataService → [LOCAL: Database | REDE: Client → Server] → TXT  │
│                                                                         │
│  LISTAGEM DE TURMAS:                                                   │
│  GUI ← DataService ← [LOCAL: Database | REDE: Server → Client] ← TXT  │
│                                                                         │
│  ADICIONAR ALUNO:                                                      │
│  1. Atualiza registro da TURMA (adiciona ID do aluno)                 │
│  2. Atualiza registro do ALUNO (define id_turma)                      │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      ARQUIVOS DO MÓDULO                                 │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  modulo_turmas/                                                        │
│  ├── __init__.py              # Inicializador                         │
│  ├── README.md                # Documentação                          │
│  ├── LISTA_ARQUIVOS.md        # Lista de arquivos                     │
│  ├── DIAGRAMA.md              # Este arquivo                          │
│  ├── exemplo_uso.py           # Exemplos práticos                     │
│  ├── turma_model.py           # Modelo de dados                       │
│  ├── turma_database.py        # Acesso local                          │
│  ├── turma_data_service.py    # Abstração LOCAL/REDE                  │
│  ├── turma_client.py          # Cliente de rede                       │
│  ├── turma_server.py          # Servidor de rede                      │
│  └── turma_gui.py             # Interface gráfica                     │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## Legenda

- **→** : Fluxo de dados ou dependência
- **[   ]** : Decisão condicional
- **1:N** : Relacionamento um-para-muitos
- **◀─▶** : Comunicação bidirecional
- **┌─┐** : Componente ou módulo
