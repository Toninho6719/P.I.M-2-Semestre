# main.py
# Ponto de entrada do sistema acadêmico com controle de acesso.

import database as db
from models import Aluno, Turma, Aula, Atividade, Nota, Chamada
import getpass # Para esconder a senha

# --- Funções de Interface (Menus) ---

def menu_adm():
    """Exibe o menu para administradores."""
    print("\n--- Menu do Administrador ---")
    print("1. Cadastrar Novo Usuário")
    print("2. Listar Usuários")
    print("3. Cadastrar Aluno")
    print("4. Listar Alunos")
    print("5. Cadastrar Turma")
    print("6. Listar Turmas")
    print("7. Registrar Aula")
    print("8. Listar Aulas")
    print("9. Registrar Atividade")
    print("10. Listar Atividades")
    print("11. Lançar/Editar Nota")
    print("12. Visualizar Notas de Aluno")
    print("13. Registrar Chamada de Aula")
    print("14. Listar Chamada de Aula")
    print("0. Sair (Logout)")
    return input("Escolha uma opção: ")

def menu_professor():
    """Exibe o menu para professores."""
    print("\n--- Menu do Professor ---")
    print("1. Listar Alunos")
    print("2. Listar Turmas")
    print("3. Registrar Aula")
    print("4. Listar Aulas")
    print("5. Registrar Atividade")
    print("6. Listar Atividades")
    print("7. Lançar/Editar Nota")
    print("8. Visualizar Notas de Aluno")
    print("9. Registrar Chamada de Aula")
    print("10. Listar Chamada de Aula")
    print("0. Sair (Logout)")
    return input("Escolha uma opção: ")

def menu_aluno():
    """Exibe o menu para alunos."""
    print("\n--- Menu do Aluno ---")
    print("1. Listar Turmas")
    print("2. Listar Aulas")
    print("3. Listar Atividades")
    print("4. Ver Minhas Notas")
    print("5. Ver Minhas Presenças")
    print("0. Sair (Logout)")
    return input("Escolha uma opção: ")

# --- Funções de Ações ---

def cadastrar_novo_usuario():
    print("\n--- Cadastro de Novo Usuário ---")
    username = input("Digite o nome de usuário: ")
    if db.usuario_existe(username):
        print("Erro: Nome de usuário já existe.")
        return
    
    senha = getpass.getpass("Digite a senha: ")
    
    while True:
        papel = input("Digite o papel (adm, professor, aluno): ").lower()
        if papel in ["adm", "professor", "aluno"]:
            break
        else:
            print("Papel inválido. Escolha entre 'adm', 'professor' ou 'aluno'.")
            
    id_usuario = db.get_proximo_id(db.ARQUIVO_USUARIOS)
    db.salvar_usuario(id_usuario, username, senha, papel)
    print(f"Usuário '{username}' cadastrado com sucesso como '{papel}'.")

def listar_todos_usuarios():
    print("\n--- Lista de Usuários ---")
    usuarios = db.listar_usuarios()
    if not usuarios:
        print("Nenhum usuário cadastrado.")
    for id, username, papel in usuarios:
        print(f"ID: {id}, Usuário: {username}, Papel: {papel}")

def cadastrar_aluno():
    nome = input("Digite o nome do aluno: ")
    aluno = Aluno(id=db.get_proximo_id(db.ARQUIVO_ALUNOS), nome=nome)
    db.salvar_aluno(aluno)
    print(f"Aluno '{nome}' cadastrado com sucesso!")

def listar_todos_alunos():
    print("\n--- Lista de Alunos ---")
    alunos = db.listar_alunos()
    if not alunos:
        print("Nenhum aluno cadastrado.")
    for aluno in alunos:
        print(aluno)
    return alunos

def cadastrar_turma():
    nome_disciplina = input("Digite o nome da disciplina da turma: ")
    turma = Turma(id=db.get_proximo_id(db.ARQUIVO_TURMAS), nome_disciplina=nome_disciplina)
    db.salvar_turma(turma)
    print(f"Turma '{nome_disciplina}' cadastrada com sucesso!")

def listar_todas_turmas():
    print("\n--- Lista de Turmas ---")
    turmas = db.listar_turmas()
    if not turmas:
        print("Nenhuma turma cadastrada.")
    for turma in turmas:
        print(turma)

def registrar_aula():
    id_turma = input("Digite o ID da turma para registrar a aula: ")
    data = input("Digite a data da aula (DD/MM/AAAA): ")
    topico = input("Digite o tópico da aula: ")
    aula = Aula(id=db.get_proximo_id(db.ARQUIVO_AULAS), id_turma=id_turma, data=data, topico=topico)
    db.salvar_aula(aula)
    print("Aula registrada com sucesso!")

def listar_todas_aulas():
    print("\n--- Lista de Aulas ---")
    aulas = db.listar_aulas()
    if not aulas:
        print("Nenhuma aula registrada.")
    for aula in aulas:
        print(aula)
    return aulas

def registrar_atividade():
    id_turma = input("Digite o ID da turma para a atividade: ")
    descricao = input("Digite a descrição da atividade: ")
    atividade = Atividade(id=db.get_proximo_id(db.ARQUIVO_ATIVIDADES), id_turma=id_turma, descricao=descricao)
    db.salvar_atividade(atividade)
    print("Atividade registrada com sucesso!")

def listar_todas_atividades():
    print("\n--- Lista de Atividades ---")
    atividades = db.listar_atividades()
    if not atividades:
        print("Nenhuma atividade registrada.")
    for atividade in atividades:
        print(atividade)
    return atividades

def lancar_ou_editar_nota():
    print("\n--- Lançar/Editar Nota ---")
    listar_todos_alunos()
    id_aluno = input("Digite o ID do aluno: ")
    listar_todas_atividades()
    id_atividade = input("Digite o ID da atividade: ")
    
    while True:
        try:
            nota_valor = float(input("Digite a nota (ex: 8.5): "))
            break
        except ValueError:
            print("Valor inválido. Por favor, digite um número.")

    nota = Nota(id_aluno=id_aluno, id_atividade=id_atividade, nota=nota_valor)
    db.salvar_ou_atualizar_nota(nota)
    print("Nota salva com sucesso!")

def visualizar_notas_aluno(id_aluno_logado=None):
    print("\n--- Visualizar Notas ---")
    if id_aluno_logado:
        id_aluno_alvo = id_aluno_logado
    else:
        listar_todos_alunos()
        id_aluno_alvo = input("Digite o ID do aluno para ver as notas: ")
    
    notas = db.listar_notas_por_aluno(id_aluno_alvo)
    atividades = {atv.id: atv for atv in db.listar_atividades()}
    
    if not notas:
        print("Nenhuma nota encontrada para este aluno.")
        return

    soma_notas = 0
    print(f"\nExibindo notas para o Aluno ID: {id_aluno_alvo}")
    for nota in notas:
        atividade = atividades.get(nota.id_atividade)
        desc_atividade = atividade.descricao if atividade else "Atividade Desconhecida"
        print(f"Atividade: {desc_atividade} (ID: {nota.id_atividade}) - Nota: {nota.nota}")
        soma_notas += nota.nota
    
    # Cálculo e exibição da média
    media = soma_notas / len(notas)
    print(f"\nMédia final: {media:.2f}")

def registrar_chamada():
    print("\n--- Registrar Chamada ---")
    aulas = listar_todas_aulas()
    if not aulas:
        print("Nenhuma aula registrada para fazer a chamada.")
        return
    id_aula = input("Digite o ID da aula para registrar a chamada: ")
    
    alunos = listar_todos_alunos()
    if not alunos:
        print("Nenhum aluno cadastrado.")
        return
        
    lista_de_chamada = []
    print("Digite 'P' para Presente e 'F' para Falta.")
    for aluno in alunos:
        while True:
            status = input(f"Status para {aluno.nome} (ID: {aluno.id}): ").upper()
            if status in ['P', 'F']:
                chamada = Chamada(id_aula=id_aula, id_aluno=aluno.id, status=status)
                lista_de_chamada.append(chamada)
                break
            else:
                print("Status inválido. Use 'P' ou 'F'.")
    
    db.salvar_chamada(lista_de_chamada)
    print("Chamada registrada com sucesso!")

def listar_chamada_da_aula():
    print("\n--- Listar Chamada de Aula ---")
    aulas = listar_todas_aulas()
    if not aulas:
        return
    id_aula = input("Digite o ID da aula para ver a chamada: ")

    chamadas = db.listar_chamadas_por_aula(id_aula)
    alunos = {al.id: al for al in db.listar_alunos()}

    if not chamadas:
        print(f"Nenhum registro de chamada para a aula ID {id_aula}.")
        return

    print(f"\nChamada para a Aula ID: {id_aula}")
    for chamada in chamadas:
        aluno = alunos.get(chamada.id_aluno)
        nome_aluno = aluno.nome if aluno else "Aluno Desconhecido"
        status = "Presente" if chamada.status == 'P' else "Falta"
        print(f"Aluno: {nome_aluno} (ID: {chamada.id_aluno}) - Status: {status}")

def visualizar_minhas_presencas(id_aluno_logado):
    print("\n--- Minhas Presenças ---")
    chamadas = db.listar_chamadas_por_aluno(id_aluno_logado)
    aulas = {aula.id: aula for aula in db.listar_aulas()}

    if not chamadas:
        print("Você não possui registros de presença.")
        return

    for chamada in chamadas:
        aula = aulas.get(chamada.id_aula)
        desc_aula = f"Data: {aula.data}, Tópico: {aula.topico}" if aula else "Aula Desconhecida"
        status = "Presente" if chamada.status == 'P' else "Falta"
        print(f"Aula: {desc_aula} (ID: {chamada.id_aula}) - Status: {status}")

# --- Lógica Principal e Controle de Acesso ---

def loop_adm(id_usuario):
    while True:
        opcao = menu_adm()
        if opcao == '1': cadastrar_novo_usuario()
        elif opcao == '2': listar_todos_usuarios()
        elif opcao == '3': cadastrar_aluno()
        elif opcao == '4': listar_todos_alunos()
        elif opcao == '5': cadastrar_turma()
        elif opcao == '6': listar_todas_turmas()
        elif opcao == '7': registrar_aula()
        elif opcao == '8': listar_todas_aulas()
        elif opcao == '9': registrar_atividade()
        elif opcao == '10': listar_todas_atividades()
        elif opcao == '11': lancar_ou_editar_nota()
        elif opcao == '12': visualizar_notas_aluno()
        elif opcao == '13': registrar_chamada()
        elif opcao == '14': listar_chamada_da_aula()
        elif opcao == '0': break
        else: print("Opção inválida.")

def loop_professor(id_usuario):
    while True:
        opcao = menu_professor()
        if opcao == '1': listar_todos_alunos()
        elif opcao == '2': listar_todas_turmas()
        elif opcao == '3': registrar_aula()
        elif opcao == '4': listar_todas_aulas()
        elif opcao == '5': registrar_atividade()
        elif opcao == '6': listar_todas_atividades()
        elif opcao == '7': lancar_ou_editar_nota()
        elif opcao == '8': visualizar_notas_aluno()
        elif opcao == '9': registrar_chamada()
        elif opcao == '10': listar_chamada_da_aula()
        elif opcao == '0': break
        else: print("Opção inválida.")

def loop_aluno(id_usuario):
    while True:
        opcao = menu_aluno()
        if opcao == '1': listar_todas_turmas()
        elif opcao == '2': listar_todas_aulas()
        elif opcao == '3': listar_todas_atividades()
        elif opcao == '4': visualizar_notas_aluno(id_aluno_logado=id_usuario)
        elif opcao == '5': visualizar_minhas_presencas(id_aluno_logado=id_usuario)
        elif opcao == '0': break
        else: print("Opção inválida.")

def tela_login():
    """Gerencia o processo de login."""
    print("\n--- Login do Sistema ---")
    username = input("Usuário: ")
    senha = getpass.getpass("Senha: ")
    
    id_usuario, papel = db.verificar_usuario(username, senha)
    
    if papel == "adm":
        print(f"Login bem-sucedido! Bem-vindo, {username} (Admin).")
        loop_adm(id_usuario)
    elif papel == "professor":
        print(f"Login bem-sucedido! Bem-vindo, {username} (Professor).")
        loop_professor(id_usuario)
    elif papel == "aluno":
        # Para o aluno, o ID do usuário deve corresponder ao ID do aluno
        print(f"Login bem-sucedido! Bem-vindo, {username} (Aluno).")
        loop_aluno(id_usuario)
    else:
        print("Usuário ou senha inválidos.")

def setup_primeiro_adm():
    """Verifica se existe um ADM e, se não, força a criação do primeiro."""
    usuarios = db.listar_usuarios()
    adm_existe = any(papel == 'adm' for _, _, papel in usuarios)
    
    if not adm_existe:
        print("Nenhum administrador encontrado. Vamos configurar o primeiro usuário ADM.")
        cadastrar_novo_usuario()
        # Garante que o usuário criado foi um ADM
        if not any(papel == 'adm' for _, _, papel in db.listar_usuarios()):
             print("ERRO: O primeiro usuário deve ser um ADM. O sistema será encerrado.")
             exit()


def main():
    """Função principal que executa o loop do programa."""
    db.inicializar_arquivos()
    setup_primeiro_adm()

    while True:
        tela_login()
        print("\nLogout realizado. Você voltou para a tela de login.")
        # O loop continua, permitindo que outro usuário faça login.
        # Para encerrar o programa, o usuário precisaria fechar o terminal.

if __name__ == "__main__":
    main()