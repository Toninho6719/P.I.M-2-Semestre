"""
Servidor Proxy para Sistema Acadêmico PIM
Gerencia múltiplas conexões de clientes em uma rede LAN
"""

import socket
import threading
import json
import hashlib
import sys
import os
from datetime import datetime

# Adiciona o diretório ao path para importar os módulos
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import database as db
from models import Aluno, Turma, Aula, Atividade, Nota, Chamada, Professor

class AcademicServerProxy:
    def __init__(self, host='0.0.0.0', port=5000):
        self.host = host
        self.port = port
        self.server_socket = None
        self.clients = []
        self.sessions = {}  # Armazena sessões ativas {session_id: {user_info}}
        self.active_connections = 0
        
    def start(self):
        """Inicia o servidor proxy"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(10)
            
            print("=" * 60)
            print("🚀 SERVIDOR PROXY - SISTEMA ACADÊMICO PIM")
            print("=" * 60)
            print(f"📡 Servidor iniciado em: {self.host}:{self.port}")
            print(f"⏰ Data/Hora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
            print(f"📁 Banco de dados: Arquivos .txt")
            print("=" * 60)
            print("✅ Aguardando conexões de clientes...\n")
            
            while True:
                try:
                    client_socket, address = self.server_socket.accept()
                    self.active_connections += 1
                    
                    print(f"✅ [{datetime.now().strftime('%H:%M:%S')}] Cliente conectado: {address[0]}:{address[1]}")
                    print(f"   Total de conexões ativas: {self.active_connections}\n")
                    
                    # Cria thread para cada cliente
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address),
                        daemon=True
                    )
                    client_thread.start()
                    
                    self.clients.append((client_socket, address))
                    
                except KeyboardInterrupt:
                    break
                except Exception as e:
                    print(f"❌ Erro ao aceitar conexão: {e}")
                    
        except Exception as e:
            print(f"❌ Erro ao iniciar servidor: {e}")
        finally:
            self.shutdown()
    
    def handle_client(self, client_socket, address):
        """Gerencia requisições de um cliente específico"""
        try:
            while True:
                # Recebe dados do cliente
                data = client_socket.recv(8192).decode('utf-8')
                
                if not data:
                    break
                
                # Processa requisição
                request = json.loads(data)
                action = request.get('action')
                
                print(f"📨 [{datetime.now().strftime('%H:%M:%S')}] {address[0]} -> {action}")
                
                response = self.process_request(request, address)
                
                # Envia resposta
                response_json = json.dumps(response, ensure_ascii=False)
                client_socket.send(response_json.encode('utf-8'))
                
        except ConnectionResetError:
            pass
        except Exception as e:
            print(f"❌ Erro com cliente {address}: {str(e)}")
        finally:
            client_socket.close()
            if (client_socket, address) in self.clients:
                self.clients.remove((client_socket, address))
            self.active_connections -= 1
            print(f"🔌 [{datetime.now().strftime('%H:%M:%S')}] Cliente desconectado: {address[0]}:{address[1]}")
            print(f"   Total de conexões ativas: {self.active_connections}\n")
    
    def process_request(self, request, address):
        """Processa diferentes tipos de requisições"""
        action = request.get('action')
        data = request.get('data', {})
        
        try:
            # Autenticação
            if action == 'login':
                return self.handle_login(data, address)
            elif action == 'logout':
                return self.handle_logout(data)
            
            # Ações que não precisam de sessão (consultas públicas)
            if action == 'verificar_admin_existe':
                return self.handle_verificar_admin_existe()
            
            if action == 'gerar_ra':
                return self.handle_gerar_ra(data)
            
            # Ações que não precisam de sessão (primeiro acesso)
            if action == 'cadastrar_usuario':
                # Permite cadastro de primeiro administrador sem sessão
                usuarios = db.listar_usuarios()
                if len(usuarios) == 0:
                    print("   ⚠️  Permitindo cadastro de primeiro administrador sem sessão")
                    return self.handle_cadastrar_usuario(data)
            
            # Validar sessão para ações protegidas
            session_id = data.get('session_id')
            print(f"   🔐 Validando sessão: {session_id[:16] if session_id else 'None'}...")
            if not self.validate_session(session_id):
                print(f"   ❌ Sessão inválida! Sessões ativas: {len(self.sessions)}")
                return {'status': 'error', 'message': 'Sessão inválida ou expirada'}
            
            # Roteamento de ações
            handlers = {
                'listar_usuarios': self.handle_listar_usuarios,
                'listar_alunos': self.handle_listar_alunos,
                'listar_professores': self.handle_listar_professores,
                'listar_turmas': self.handle_listar_turmas,
                'listar_aulas': self.handle_listar_aulas,
                'listar_atividades': self.handle_listar_atividades,
                'listar_notas_aluno': self.handle_listar_notas_aluno,
                'listar_chamadas_aluno': self.handle_listar_chamadas_aluno,
                'listar_chamadas_aula': self.handle_listar_chamadas_aula,
                'cadastrar_usuario': self.handle_cadastrar_usuario,
                'cadastrar_aluno': self.handle_cadastrar_aluno,
                'cadastrar_professor': self.handle_cadastrar_professor,
                'cadastrar_turma': self.handle_cadastrar_turma,
                'registrar_aula': self.handle_registrar_aula,
                'registrar_atividade': self.handle_registrar_atividade,
                'lancar_nota': self.handle_lancar_nota,
                'sobrescrever_nota': self.handle_sobrescrever_nota,
                'registrar_chamada': self.handle_registrar_chamada,
                'sobrescrever_chamada': self.handle_sobrescrever_chamada,
                'ativar_desativar_usuario': self.handle_ativar_desativar_usuario,
                'buscar_aluno': self.handle_buscar_aluno,
                'buscar_aluno_por_ra': self.handle_buscar_aluno_por_ra,
                'buscar_professor_por_ra': self.handle_buscar_professor_por_ra,
                'buscar_turma': self.handle_buscar_turma,
                'excluir_turma': self.handle_excluir_turma,
                'atualizar_turma_aluno': self.handle_atualizar_turma_aluno,
                'adicionar_aluno_a_turma': self.handle_adicionar_aluno_a_turma,
            }
            
            handler = handlers.get(action)
            if handler:
                return handler(data)
            else:
                return {'status': 'error', 'message': f'Ação desconhecida: {action}'}
                
        except Exception as e:
            return {'status': 'error', 'message': f'Erro no servidor: {str(e)}'}
    
    def validate_session(self, session_id):
        """Valida se a sessão existe e está ativa"""
        return session_id in self.sessions
    
    # ===== HANDLERS DE AUTENTICAÇÃO =====
    
    def handle_login(self, data, address):
        """Autentica usuário"""
        username = data.get('username')
        password = data.get('password')
        
        print(f"   📋 Tentativa de login - Usuário: {username}")
        print(f"   🔍 Verificando credenciais no banco de dados...")
        
        id_usuario, papel, nome = db.verificar_usuario(username, password)
        
        if papel:
            # Busca o RA do usuário
            ra = ''
            usuarios = db.listar_usuarios()
            for u in usuarios:
                if u[0] == id_usuario:
                    ra = u[5]  # Campo RA
                    break
            
            # Cria sessão única
            session_id = hashlib.sha256(
                f"{username}{address}{datetime.now().timestamp()}".encode()
            ).hexdigest()
            
            self.sessions[session_id] = {
                'id_usuario': id_usuario,
                'nome': nome,
                'papel': papel,
                'ra': ra,
                'address': address,
                'login_time': datetime.now().isoformat()
            }
            
            print(f"   ✓ Login bem-sucedido: {nome} ({papel}) RA: {ra}")
            
            return {
                'status': 'success',
                'data': {
                    'session_id': session_id,
                    'id_usuario': id_usuario,
                    'nome': nome,
                    'papel': papel,
                    'ra': ra
                }
            }
        else:
            print(f"   ✗ Tentativa de login falhou: {username}")
            return {'status': 'error', 'message': 'Usuário ou senha inválidos'}
    
    def handle_logout(self, data):
        """Encerra sessão"""
        session_id = data.get('session_id')
        if session_id in self.sessions:
            user_info = self.sessions[session_id]
            del self.sessions[session_id]
            print(f"   ✓ Logout: {user_info['nome']}")
            return {'status': 'success', 'message': 'Logout realizado'}
        return {'status': 'error', 'message': 'Sessão inválida'}
    
    def handle_verificar_admin_existe(self):
        """Verifica se existe pelo menos um administrador (não requer autenticação)"""
        usuarios = db.listar_usuarios()
        existe_admin = any(usuario[3] == 'adm' for usuario in usuarios)
        print(f"   🔍 Verificação de admin: {existe_admin}")
        return {
            'status': 'success',
            'data': {'existe': existe_admin}
        }
    
    def handle_gerar_ra(self, data):
        """Gera novo RA (não requer autenticação)"""
        tipo = data.get('tipo', 'aluno')
        ra = db.gerar_novo_ra(tipo)
        print(f"   🎫 RA gerado: {ra} (tipo: {tipo})")
        return {
            'status': 'success',
            'data': {'ra': ra}
        }
    
    # ===== HANDLERS DE LISTAGEM =====
    
    def handle_listar_usuarios(self, data):
        """Lista todos os usuários"""
        usuarios = db.listar_usuarios()
        usuarios_list = [
            {
                'id': u[0],
                'username': u[1],
                'papel': u[3],
                'nome': u[4],
                'ra': u[5] if u[5] else '',
                'ativo': u[6]
            }
            for u in usuarios
        ]
        return {'status': 'success', 'data': usuarios_list}
    
    def handle_listar_alunos(self, data):
        """Lista alunos"""
        filter_ativos = data.get('filter_ativos', True)
        alunos = db.listar_alunos(filter_ativos=filter_ativos)
        alunos_list = [
            {
                'id': a.id,
                'nome': a.nome,
                'ra': a.ra,
                'id_turma': a.id_turma if a.id_turma else None
            }
            for a in alunos
        ]
        return {'status': 'success', 'data': alunos_list}
    
    def handle_listar_professores(self, data):
        """Lista professores"""
        professores = db.listar_professores()
        prof_list = [
            {
                'id': p.id,
                'nome': p.nome,
                'ra': p.ra
            }
            for p in professores
        ]
        return {'status': 'success', 'data': prof_list}
    
    def handle_listar_turmas(self, data):
        """Lista turmas"""
        turmas = db.listar_turmas()
        turmas_list = [
            {
                'id': t.id,
                'nome_disciplina': t.nome_disciplina,
                'id_alunos': t.id_alunos
            }
            for t in turmas
        ]
        return {'status': 'success', 'data': turmas_list}
    
    def handle_listar_aulas(self, data):
        """Lista aulas"""
        aulas = db.listar_aulas()
        aulas_list = [
            {
                'id': a.id,
                'id_turma': a.id_turma,
                'data': a.data,
                'topico': a.topico,
                'id_professor': a.id_professor
            }
            for a in aulas
        ]
        return {'status': 'success', 'data': aulas_list}
    
    def handle_listar_atividades(self, data):
        """Lista atividades"""
        atividades = db.listar_atividades()
        ativ_list = [
            {
                'id': a.id,
                'id_turma': a.id_turma,
                'descricao': a.descricao,
                'id_professor': a.id_professor if a.id_professor else ''
            }
            for a in atividades
        ]
        return {'status': 'success', 'data': ativ_list}
    
    def handle_listar_notas_aluno(self, data):
        """Lista notas de um aluno"""
        id_aluno = data.get('id_aluno')
        notas = db.listar_notas_por_aluno(id_aluno)
        notas_list = [
            {
                'id_aluno': n.id_aluno,
                'id_atividade': n.id_atividade,
                'nota': n.nota
            }
            for n in notas
        ]
        return {'status': 'success', 'data': notas_list}
    
    def handle_listar_chamadas_aluno(self, data):
        """Lista chamadas de um aluno"""
        id_aluno = data.get('id_aluno')
        chamadas = db.listar_chamadas_por_aluno(id_aluno)
        chamadas_list = [
            {
                'id_aula': c.id_aula,
                'id_aluno': c.id_aluno,
                'status': c.status
            }
            for c in chamadas
        ]
        return {'status': 'success', 'data': chamadas_list}
    
    def handle_listar_chamadas_aula(self, data):
        """Lista chamadas de uma aula"""
        id_aula = data.get('id_aula')
        chamadas = db.listar_chamadas_por_aula(id_aula)
        chamadas_list = [
            {
                'id_aula': c.id_aula,
                'id_aluno': c.id_aluno,
                'status': c.status
            }
            for c in chamadas
        ]
        return {'status': 'success', 'data': chamadas_list}
    
    # ===== HANDLERS DE CADASTRO =====
    
    def handle_cadastrar_usuario(self, data):
        """Cadastra novo usuário"""
        print(f"🖥️  [SERVER] Recebeu requisição cadastrar_usuario: {data.get('username')}")
        # Aceita ID do cliente se fornecido, senão gera novo
        id_usuario = data.get('id') or db.get_proximo_id(db.ARQUIVO_USUARIOS)
        print(f"🖥️  [SERVER] ID usado: {id_usuario} (fornecido: {data.get('id') is not None})")
        db.salvar_usuario(
            id=id_usuario,
            username=data['username'],
            senha=data['senha'],
            papel=data['papel'],
            nome=data['nome'],
            ra=data.get('ra'),
            ativo=True
        )
        print(f"🖥️  [SERVER] Usuário {data.get('username')} salvo com ID {id_usuario}!")
        return {'status': 'success', 'message': 'Usuário cadastrado', 'id': id_usuario}
    
    def handle_cadastrar_aluno(self, data):
        """Cadastra aluno"""
        print(f"🖥️  [SERVER] Cadastrando aluno: {data.get('nome')}")
        # Usa o ID enviado pelo cliente (que é o mesmo ID do usuário)
        id_aluno = data.get('id')
        if not id_aluno:
            id_aluno = db.get_proximo_id(db.ARQUIVO_ALUNOS)
        ra = db.gerar_novo_ra('aluno')  # Gera RA no servidor
        print(f"🖥️  [SERVER] ID usado: {id_aluno}, RA gerado: {ra}")
        aluno = Aluno(
            id=id_aluno,
            nome=data['nome'],
            ra=ra,
            id_turma=data.get('id_turma')
        )
        db.salvar_aluno(aluno)
        print(f"🖥️  [SERVER] Aluno {data.get('nome')} salvo com ID {id_aluno}")
        return {'status': 'success', 'message': 'Aluno cadastrado', 'id': id_aluno, 'ra': ra}
    
    def handle_cadastrar_professor(self, data):
        """Cadastra professor"""
        print(f"🖥️  [SERVER] Cadastrando professor: {data.get('nome')}")
        # Usa o ID enviado pelo cliente (que é o mesmo ID do usuário)
        id_professor = data.get('id')
        if not id_professor:
            id_professor = db.get_proximo_id(db.ARQUIVO_PROFESSORES)
        ra = db.gerar_novo_ra('professor')  # Gera RA no servidor
        print(f"🖥️  [SERVER] ID usado: {id_professor}, RA gerado: {ra}")
        professor = Professor(
            id=id_professor,
            nome=data['nome'],
            ra=ra
        )
        db.salvar_professor(professor)
        print(f"🖥️  [SERVER] Professor {data.get('nome')} salvo com ID {id_professor}")
        return {'status': 'success', 'message': 'Professor cadastrado', 'id': id_professor, 'ra': ra}
    
    def handle_cadastrar_turma(self, data):
        """Cadastra turma"""
        print(f"🖥️  [SERVER] Cadastrando turma: {data.get('nome_disciplina')}")
        # Usa o ID enviado se disponível, senão gera novo
        id_turma = data.get('id')
        if not id_turma:
            id_turma = db.get_proximo_id(db.ARQUIVO_TURMAS)
        turma = Turma(
            id=id_turma,
            nome_disciplina=data['nome_disciplina'],
            id_alunos=data.get('id_alunos', [])
        )
        db.salvar_turma(turma)
        print(f"🖥️  [SERVER] Turma {data.get('nome_disciplina')} salva com ID {id_turma}")
        return {'status': 'success', 'message': 'Turma cadastrada', 'id': id_turma}
    
    def handle_registrar_aula(self, data):
        """Registra aula"""
        print(f"🖥️  [SERVER] Registrando aula: {data.get('topico')}")
        id_aula = db.get_proximo_id(db.ARQUIVO_AULAS)
        aula = Aula(
            id=id_aula,
            id_turma=data['id_turma'],
            data=data['data'],
            topico=data['topico'],
            id_professor=data['id_professor']
        )
        db.salvar_aula(aula)
        print(f"🖥️  [SERVER] Aula registrada com ID {id_aula}")
        return {'status': 'success', 'message': 'Aula registrada', 'id': id_aula}
    
    def handle_registrar_atividade(self, data):
        """Registra atividade"""
        print(f"🖥️  [SERVER] Registrando atividade: {data.get('descricao')[:50]}...")
        id_atividade = db.get_proximo_id(db.ARQUIVO_ATIVIDADES)
        atividade = Atividade(
            id=id_atividade,
            id_turma=data['id_turma'],
            descricao=data['descricao'],
            id_professor=data.get('id_professor')
        )
        db.salvar_atividade(atividade)
        print(f"🖥️  [SERVER] Atividade registrada com ID {id_atividade}")
        return {'status': 'success', 'message': 'Atividade registrada', 'id': id_atividade}
    
    def handle_lancar_nota(self, data):
        """Lança nota"""
        nota = Nota(
            id_aluno=data['id_aluno'],
            id_atividade=data['id_atividade'],
            nota=float(data['nota'])
        )
        db.salvar_ou_atualizar_nota(nota)
        return {'status': 'success', 'message': 'Nota lançada'}
    
    def handle_sobrescrever_nota(self, data):
        """Sobrescreve nota existente (garante atualização correta)"""
        id_aluno = data['id_aluno']
        id_atividade = data['id_atividade']
        nova_nota = float(data['nota'])
        
        nota_existia = db.sobrescrever_nota(id_aluno, id_atividade, nova_nota)
        
        if nota_existia:
            return {'status': 'success', 'message': 'Nota atualizada com sucesso'}
        else:
            return {'status': 'success', 'message': 'Nova nota registrada com sucesso'}
    
    def handle_registrar_chamada(self, data):
        """Registra chamada"""
        lista_chamadas = [
            Chamada(
                id_aula=c['id_aula'],
                id_aluno=c['id_aluno'],
                status=c['status']
            )
            for c in data['chamadas']
        ]
        db.salvar_chamada(lista_chamadas)
        return {'status': 'success', 'message': 'Chamada registrada'}
    
    def handle_sobrescrever_chamada(self, data):
        """Sobrescreve chamadas de uma aula (remove antigas e adiciona novas)"""
        id_aula = data['id_aula']
        lista_chamadas = [
            Chamada(
                id_aula=c['id_aula'],
                id_aluno=c['id_aluno'],
                status=c['status']
            )
            for c in data['chamadas']
        ]
        db.sobrescrever_chamada_por_aula(id_aula, lista_chamadas)
        return {'status': 'success', 'message': 'Chamada atualizada com sucesso'}
    
    def handle_ativar_desativar_usuario(self, data):
        """Ativa ou desativa usuário"""
        success = db.set_usuario_ativo(data['id_usuario'], data['ativo'])
        if success:
            return {'status': 'success', 'message': 'Status atualizado'}
        return {'status': 'error', 'message': 'Erro ao atualizar'}
    
    def handle_buscar_aluno(self, data):
        """Busca aluno por ID"""
        aluno = db.buscar_aluno_por_id(data['id_aluno'])
        if aluno:
            return {
                'status': 'success',
                'data': {
                    'id': aluno.id,
                    'nome': aluno.nome,
                    'ra': aluno.ra,
                    'id_turma': aluno.id_turma if aluno.id_turma else None
                }
            }
        return {'status': 'error', 'message': 'Aluno não encontrado'}

    def handle_buscar_aluno_por_ra(self, data):
        """Busca aluno por RA"""
        aluno = db.buscar_aluno_por_ra(data['ra_aluno'])
        if aluno:
            return {
                'status': 'success',
                'data': {
                    'id': aluno.id,
                    'nome': aluno.nome,
                    'ra': aluno.ra,
                    'id_turma': aluno.id_turma if aluno.id_turma else None
                }
            }
        return {'status': 'error', 'message': 'Aluno não encontrado'}

    def handle_buscar_professor_por_ra(self, data):
        """Busca professor por RA"""
        professor = db.buscar_professor_por_ra(data['ra_professor'])
        if professor:
            return {
                'status': 'success',
                'data': {
                    'id': professor.id,
                    'nome': professor.nome,
                    'ra': professor.ra
                }
            }
        return {'status': 'error', 'message': 'Professor não encontrado'}
    
    def handle_buscar_turma(self, data):
        """Busca turma por ID"""
        turma = db.buscar_turma_por_id(data['id_turma'])
        if turma:
            return {
                'status': 'success',
                'data': {
                    'id': turma.id,
                    'nome_disciplina': turma.nome_disciplina,
                    'id_alunos': turma.id_alunos
                }
            }
        return {'status': 'error', 'message': 'Turma não encontrada'}
    
    def handle_excluir_turma(self, data):
        """Exclui uma turma"""
        id_turma = data.get('id_turma')
        print(f"🗑️  [SERVER] Excluindo turma ID: {id_turma}")
        try:
            db.excluir_turma(id_turma)
            print(f"✅ [SERVER] Turma {id_turma} excluída com sucesso")
            return {'status': 'success', 'message': 'Turma excluída com sucesso'}
        except Exception as e:
            print(f"❌ [SERVER] Erro ao excluir turma: {e}")
            return {'status': 'error', 'message': f'Erro ao excluir turma: {str(e)}'}

    def handle_atualizar_turma_aluno(self, data):
        """Atualiza a turma de um aluno"""
        try:
            id_aluno = data['id_aluno']
            id_turma = data['id_turma']
            print(f"🖥️  [SERVER] Atualizando aluno {id_aluno} para turma {id_turma}")
            db.atualizar_turma_aluno(id_aluno, id_turma)
            print(f"✅ [SERVER] Aluno {id_aluno} atualizado com sucesso")
            return {'status': 'success', 'message': 'Aluno atualizado'}
        except Exception as e:
            print(f"❌ [SERVER] Erro ao atualizar aluno: {e}")
            return {'status': 'error', 'message': f'Erro ao atualizar aluno: {str(e)}'}

    def handle_adicionar_aluno_a_turma(self, data):
        """Adiciona aluno à lista de alunos da turma"""
        try:
            id_aluno = data['id_aluno']
            id_turma = data['id_turma']
            print(f"🖥️  [SERVER] Adicionando aluno {id_aluno} à turma {id_turma}")
            db.adicionar_aluno_a_turma(id_aluno, id_turma)
            print(f"✅ [SERVER] Aluno {id_aluno} adicionado à turma com sucesso")
            return {'status': 'success', 'message': 'Aluno adicionado à turma'}
        except Exception as e:
            print(f"❌ [SERVER] Erro ao adicionar aluno: {e}")
            return {'status': 'error', 'message': f'Erro ao adicionar aluno: {str(e)}'}
    
    def shutdown(self):
        """Encerra o servidor"""
        print("\n" + "=" * 60)
        print("🛑 Encerrando servidor...")
        
        for client_socket, address in self.clients:
            try:
                client_socket.close()
            except:
                pass
        
        if self.server_socket:
            self.server_socket.close()
        
        print(f"✅ Servidor encerrado às {datetime.now().strftime('%H:%M:%S')}")
        print("=" * 60)


def main():
    """Função principal"""
    print("\n")
    print("╔════════════════════════════════════════════════════════════╗")
    print("║     SERVIDOR PROXY - SISTEMA ACADÊMICO PIM                ║")
    print("║            Modelo Cliente-Servidor com Proxy              ║")
    print("╚════════════════════════════════════════════════════════════╝")
    print("\n")
    
    # Inicializa banco de dados
    db.inicializar_arquivos()
    
    # Configuração do servidor
    HOST = '0.0.0.0'  # Aceita conexões de qualquer IP
    PORT = 5000
    
    print(f"📝 Configuração:")
    print(f"   Host: {HOST} (todas as interfaces)")
    print(f"   Porta: {PORT}")
    print(f"   Protocolo: TCP/IP")
    print(f"   Encoding: UTF-8")
    print("\n")
    
    server = AcademicServerProxy(host=HOST, port=PORT)
    
    try:
        server.start()
    except KeyboardInterrupt:
        print("\n")
        server.shutdown()
    except Exception as e:
        print(f"\n❌ Erro fatal: {e}")
        server.shutdown()


if __name__ == "__main__":
    main()
