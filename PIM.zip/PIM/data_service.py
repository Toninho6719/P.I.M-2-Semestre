"""
Data Service - Camada de Abstração para Acesso a Dados
Decide automaticamente entre modo LOCAL (database.py) ou REDE (client_proxy.py)
"""

import importlib
from models import Aluno, Turma, Aula, Atividade, Nota, Chamada, Professor


class DataService:
    """
    Adapter que abstrai o acesso aos dados.
    Em modo LOCAL: acessa arquivos .txt via database.py
    Em modo REDE: acessa via client_proxy.py conectado ao servidor
    """
    
    def __init__(self):
        # Recarrega config_rede para pegar valores atualizados
        import config_rede
        importlib.reload(config_rede)
        
        self.modo_rede = config_rede.MODO_REDE
        self.network_client = None
        self.session_id = None
        
        print(f"🔧 DataService inicializado em modo: {'REDE' if self.modo_rede else 'LOCAL'}")
        
        if self.modo_rede:
            # Modo rede: inicializa cliente mas não conecta ainda
            # Conexão será feita no login
            from client_proxy import AcademicClient
            self.network_client = AcademicClient(
                server_host=config_rede.SERVER_HOST,
                server_port=config_rede.SERVER_PORT
            )
            print(f"🌐 Cliente de rede configurado para {config_rede.SERVER_HOST}:{config_rede.SERVER_PORT}")
        else:
            # Modo local: importa e inicializa database
            import database as db
            self.db = db
            self.db.inicializar_arquivos()
            print("💾 Acesso local aos arquivos configurado")
    
    def connect(self):
        """Conecta ao servidor (apenas modo rede)"""
        if self.modo_rede and self.network_client:
            return self.network_client.connect()
        return True
    
    def disconnect(self):
        """Desconecta do servidor (apenas modo rede)"""
        if self.modo_rede and self.network_client:
            try:
                if self.network_client.session_id:
                    self.network_client.logout()
                self.network_client.disconnect()
            except:
                pass
    
    # ===== AUTENTICAÇÃO =====
    
    def verificar_admin_existe(self):
        """Verifica se existe pelo menos um administrador cadastrado"""
        if self.modo_rede:
            # Em modo rede, usa método específico que não requer autenticação
            if not self.network_client.connected:
                if not self.network_client.connect():
                    return False
            return self.network_client.verificar_admin_existe()
        else:
            # Modo local: verifica diretamente nos arquivos
            usuarios = self.db.listar_usuarios()
            for usuario in usuarios:
                if usuario[3] == 'adm':  # usuario[3] é o papel
                    return True
            return False
    
    def verificar_usuario(self, username, password):
        """Autentica usuário e retorna (id, papel, nome, ra)"""
        if self.modo_rede:
            if not self.network_client.connected:
                if not self.network_client.connect():
                    return None, None, None, None
            
            success, result = self.network_client.login(username, password)
            print(f"[DEBUG verificar_usuario] success={success}, result={result}")
            if success:
                self.session_id = self.network_client.session_id
                ra = result.get('ra', '')
                id_usuario = result.get('id_usuario', '')
                papel = result.get('papel', '')
                nome = result.get('nome', '')
                print(f"[DEBUG verificar_usuario] Retornando: ID={id_usuario}, papel={papel}, nome={nome}, ra={ra}")
                return id_usuario, papel, nome, ra
            return None, None, None, None
        else:
            # Modo local retorna (id, papel, nome) - adicionar RA
            resultado = self.db.verificar_usuario(username, password)
            if resultado[0]:  # Se encontrou usuário
                # Buscar o RA nos arquivos de usuários
                usuarios = self.db.listar_usuarios()
                for u in usuarios:
                    if u[0] == resultado[0]:  # Mesmo ID
                        return resultado[0], resultado[1], resultado[2], u[5]  # id, papel, nome, ra
            return None, None, None, None
    
    def usuario_existe(self, username):
        """Verifica se usuário já existe"""
        if self.modo_rede:
            # Lista todos e verifica (listar_usuarios já retorna tuplas)
            usuarios = self.listar_usuarios()
            # Formato tupla: (id, username, senha_hash, papel, nome, ra, ativo)
            return any(u[1] == username for u in usuarios)
        else:
            return self.db.usuario_existe(username)
    
    # ===== INICIALIZAÇÃO =====
    
    def inicializar_arquivos(self):
        """Inicializa arquivos (apenas modo local)"""
        if not self.modo_rede:
            self.db.inicializar_arquivos()
    
    # ===== LISTAGEM =====
    
    def listar_usuarios(self):
        """Lista todos os usuários"""
        if self.modo_rede:
            usuarios = self.network_client.listar_usuarios()
            # Converte para formato compatível com db (tupla)
            return [(u['id'], u['username'], '', u['papel'], u['nome'], u.get('ra', ''), u.get('ativo', '1')) 
                    for u in usuarios]
        else:
            return self.db.listar_usuarios()
    
    def listar_alunos(self, filter_ativos=True):
        """Lista alunos"""
        if self.modo_rede:
            alunos_dict = self.network_client.listar_alunos(filter_ativos=filter_ativos)
            return [Aluno(id=a['id'], nome=a['nome'], ra=a['ra'], 
                         id_turma=a['id_turma'] if a.get('id_turma') else None) 
                   for a in alunos_dict]
        else:
            return self.db.listar_alunos(filter_ativos=filter_ativos)
    
    def listar_alunos_sem_turma(self):
        """Lista alunos sem turma"""
        if self.modo_rede:
            # Filtra alunos ativos sem turma (None, vazio, ou "0")
            alunos = self.listar_alunos(filter_ativos=True)
            return [a for a in alunos if not a.id_turma or a.id_turma == '' or str(a.id_turma) == '0']
        else:
            return self.db.listar_alunos_sem_turma()
    
    def listar_professores(self):
        """Lista professores"""
        if self.modo_rede:
            prof_dict = self.network_client.listar_professores()
            return [Professor(id=p['id'], nome=p['nome'], ra=p['ra']) for p in prof_dict]
        else:
            return self.db.listar_professores()
    
    def listar_turmas(self):
        """Lista turmas"""
        if self.modo_rede:
            turmas_dict = self.network_client.listar_turmas()
            return [Turma(id=t['id'], nome_disciplina=t['nome_disciplina'], 
                         id_alunos=t['id_alunos']) for t in turmas_dict]
        else:
            return self.db.listar_turmas()
    
    def listar_aulas(self):
        """Lista aulas"""
        if self.modo_rede:
            aulas_dict = self.network_client.listar_aulas()
            return [Aula(id=a['id'], id_turma=a['id_turma'], data=a['data'],
                        topico=a['topico'], id_professor=a['id_professor']) 
                   for a in aulas_dict]
        else:
            return self.db.listar_aulas()
    
    def listar_atividades(self):
        """Lista atividades"""
        if self.modo_rede:
            ativ_dict = self.network_client.listar_atividades()
            return [Atividade(id=a['id'], id_turma=a['id_turma'], 
                            descricao=a['descricao'], 
                            id_professor=a.get('id_professor')) 
                   for a in ativ_dict]
        else:
            return self.db.listar_atividades()
    
    def listar_notas_por_aluno(self, id_aluno):
        """Lista notas de um aluno"""
        if self.modo_rede:
            notas_dict = self.network_client.listar_notas_aluno(id_aluno)
            return [Nota(id_aluno=n['id_aluno'], id_atividade=n['id_atividade'], 
                        nota=float(n['nota'])) for n in notas_dict]
        else:
            return self.db.listar_notas_por_aluno(id_aluno)
    
    def listar_chamadas_por_aluno(self, id_aluno):
        """Lista chamadas de um aluno"""
        if self.modo_rede:
            chamadas_dict = self.network_client.listar_chamadas_aluno(id_aluno)
            return [Chamada(id_aula=c['id_aula'], id_aluno=c['id_aluno'], 
                          status=c['status']) for c in chamadas_dict]
        else:
            return self.db.listar_chamadas_por_aluno(id_aluno)
    
    def listar_chamadas_por_aula(self, id_aula):
        """Lista chamadas de uma aula"""
        if self.modo_rede:
            chamadas_dict = self.network_client.listar_chamadas_aula(id_aula)
            return [Chamada(id_aula=c['id_aula'], id_aluno=c['id_aluno'], 
                          status=c['status']) for c in chamadas_dict]
        else:
            return self.db.listar_chamadas_por_aula(id_aula)
    
    # ===== BUSCA =====
    
    def buscar_aluno_por_id(self, id_aluno):
        """Busca aluno por ID"""
        if self.modo_rede:
            try:
                print(f"[DEBUG] Buscando aluno por ID na rede: {id_aluno}")
                aluno_dict = self.network_client.buscar_aluno(id_aluno)
                print(f"[DEBUG] Resposta do servidor: {aluno_dict}")
                if aluno_dict:
                    return Aluno(id=aluno_dict['id'], nome=aluno_dict['nome'], 
                               ra=aluno_dict['ra'], 
                               id_turma=aluno_dict.get('id_turma'))
                return None
            except Exception as e:
                print(f"[ERRO] Falha ao buscar aluno por ID: {e}")
                return None
        else:
            return self.db.buscar_aluno_por_id(id_aluno)

    def buscar_aluno_por_ra(self, ra_aluno):
        """Busca aluno por RA"""
        if self.modo_rede:
            try:
                print(f"[DEBUG] Buscando aluno por RA na rede: {ra_aluno}")
                aluno_dict = self.network_client.buscar_aluno_por_ra(ra_aluno)
                print(f"[DEBUG] Resposta do servidor: {aluno_dict}")
                if aluno_dict:
                    return Aluno(id=aluno_dict['id'], nome=aluno_dict['nome'], 
                               ra=aluno_dict['ra'], 
                               id_turma=aluno_dict.get('id_turma'))
                return None
            except Exception as e:
                print(f"[ERRO] Falha ao buscar aluno por RA: {e}")
                return None
        else:
            return self.db.buscar_aluno_por_ra(ra_aluno)

    def buscar_professor_por_ra(self, ra_professor):
        """Busca professor por RA"""
        if self.modo_rede:
            prof_dict = self.network_client.buscar_professor_por_ra(ra_professor)
            if prof_dict:
                return Professor(id=prof_dict['id'], nome=prof_dict['nome'], ra=prof_dict['ra'])
            return None
        else:
            return self.db.buscar_professor_por_ra(ra_professor)
    
    def buscar_turma_por_id(self, id_turma):
        """Busca turma por ID"""
        if self.modo_rede:
            turma_dict = self.network_client.buscar_turma(id_turma)
            if turma_dict:
                return Turma(id=turma_dict['id'], 
                           nome_disciplina=turma_dict['nome_disciplina'],
                           id_alunos=turma_dict['id_alunos'])
            return None
        else:
            return self.db.buscar_turma_por_id(id_turma)
    
    # ===== CADASTRO/ATUALIZAÇÃO =====
    
    def get_proximo_id(self, arquivo):
        """Retorna próximo ID disponível"""
        if self.modo_rede:
            # Em modo rede, o servidor gerencia IDs
            # Retorna 0 para indicar que servidor vai gerar
            return 0
        else:
            return self.db.get_proximo_id(arquivo)
    
    def salvar_usuario(self, id, username, senha, papel, nome, ra, ativo=True):
        """Salva usuário e retorna (success, id_usuario)"""
        if self.modo_rede:
            print(f"🌐 [MODO REDE] Cadastrando usuário via servidor: {username}")
            print(f"   Conectado: {self.network_client.connected}, Session: {self.network_client.session_id}")
            print(f"   ID solicitado: {id}")
            success, msg, id_usuario = self.network_client.cadastrar_usuario(
                username=username, senha=senha, papel=papel, 
                nome=nome, ra=ra, id=id
            )
            print(f"   Resultado: success={success}, msg={msg}, id={id_usuario}")
            return success, id_usuario
        else:
            print(f"💾 [MODO LOCAL] Salvando usuário localmente: {username}")
            self.db.salvar_usuario(id, username, senha, papel, nome, ra, ativo)
            return True, id
    
    def salvar_aluno(self, aluno):
        """Salva aluno e retorna (success, id_aluno, ra)"""
        if self.modo_rede:
            print(f"🌐 [MODO REDE] Cadastrando aluno via servidor: {aluno.nome}")
            success, msg, id_aluno, ra = self.network_client.cadastrar_aluno(
                id=aluno.id, nome=aluno.nome, ra=aluno.ra, 
                id_turma=aluno.id_turma
            )
            return success, id_aluno, ra
        else:
            print(f"💾 [MODO LOCAL] Salvando aluno localmente: {aluno.nome}")
            self.db.salvar_aluno(aluno)
            return True, aluno.id, aluno.ra
    
    def salvar_professor(self, professor):
        """Salva professor e retorna (success, id_professor, ra)"""
        if self.modo_rede:
            print(f"🌐 [MODO REDE] Cadastrando professor via servidor: {professor.nome}")
            print(f"   ID enviado: {professor.id}, RA: {professor.ra}")
            success, msg, id_professor, ra = self.network_client.cadastrar_professor(
                id=professor.id, nome=professor.nome, ra=professor.ra
            )
            print(f"   Resultado: success={success}, msg={msg}, id={id_professor}, ra={ra}")
            return success, id_professor, ra
        else:
            print(f"💾 [MODO LOCAL] Salvando professor localmente: {professor.nome}")
            self.db.salvar_professor(professor)
            return True, professor.id, professor.ra
    
    def salvar_turma(self, turma):
        """Salva turma e retorna (success, id_turma)"""
        if self.modo_rede:
            success, msg, id_turma = self.network_client.cadastrar_turma(
                id=turma.id, nome_disciplina=turma.nome_disciplina,
                id_alunos=turma.id_alunos
            )
            return success, id_turma
        else:
            self.db.salvar_turma(turma)
            return True, turma.id
    
    def salvar_aula(self, aula):
        """Salva aula e retorna (success, id_aula)"""
        if self.modo_rede:
            success, msg, id_aula = self.network_client.registrar_aula(
                id=aula.id, id_turma=aula.id_turma, data=aula.data,
                topico=aula.topico, id_professor=aula.id_professor
            )
            return success, id_aula
        else:
            self.db.salvar_aula(aula)
            return True, aula.id
    
    def salvar_atividade(self, atividade):
        """Salva atividade e retorna (success, id_atividade)"""
        if self.modo_rede:
            success, msg, id_atividade = self.network_client.registrar_atividade(
                id=atividade.id, id_turma=atividade.id_turma,
                descricao=atividade.descricao, id_professor=atividade.id_professor
            )
            return success, id_atividade
        else:
            self.db.salvar_atividade(atividade)
            return True, atividade.id
    
    def salvar_ou_atualizar_nota(self, nota):
        """Salva ou atualiza nota"""
        if self.modo_rede:
            success, msg = self.network_client.lancar_nota(
                id_aluno=nota.id_aluno, id_atividade=nota.id_atividade,
                nota=nota.nota
            )
            return success
        else:
            self.db.salvar_ou_atualizar_nota(nota)
            return True
    
    def sobrescrever_nota(self, id_aluno, id_atividade, nova_nota):
        """Sobrescreve nota existente (para edição garantida)"""
        if self.modo_rede:
            success, msg = self.network_client.sobrescrever_nota(
                id_aluno=id_aluno, id_atividade=id_atividade, nota=nova_nota
            )
            return success
        else:
            self.db.sobrescrever_nota(id_aluno, id_atividade, nova_nota)
            return True
    
    def salvar_chamada(self, lista_chamadas):
        """Salva lista de chamadas"""
        if self.modo_rede:
            chamadas_dict = [
                {'id_aula': c.id_aula, 'id_aluno': c.id_aluno, 'status': c.status}
                for c in lista_chamadas
            ]
            success, msg = self.network_client.registrar_chamada(chamadas_dict)
            return success
        else:
            self.db.salvar_chamada(lista_chamadas)
            return True
    
    def sobrescrever_chamada_por_aula(self, id_aula, nova_lista):
        """Sobrescreve chamadas de uma aula"""
        if self.modo_rede:
            # Modo rede: usa endpoint específico para sobrescrever
            chamadas_dict = [
                {'id_aula': c.id_aula, 'id_aluno': c.id_aluno, 'status': c.status}
                for c in nova_lista
            ]
            success, msg = self.network_client.sobrescrever_chamada(id_aula, chamadas_dict)
            return success
        else:
            self.db.sobrescrever_chamada_por_aula(id_aula, nova_lista)
            return True
    
    def set_usuario_ativo(self, id_usuario, ativo):
        """Ativa/desativa usuário"""
        if self.modo_rede:
            success, msg = self.network_client.ativar_desativar_usuario(
                id_usuario=id_usuario, ativo=ativo
            )
            return success
        else:
            return self.db.set_usuario_ativo(id_usuario, ativo)
    
    def gerar_novo_ra(self, tipo):
        """Gera novo RA"""
        if self.modo_rede:
            # Em modo rede, solicita RA do servidor
            if not self.network_client.connected:
                if not self.network_client.connect():
                    # Fallback em caso de falha
                    prefixo = 'A' if tipo == 'aluno' else 'P'
                    return f"{prefixo}000"
            return self.network_client.gerar_ra(tipo)
        else:
            return self.db.gerar_novo_ra(tipo)
    
    def adicionar_aluno_a_turma(self, id_aluno, id_turma):
        """Adiciona aluno a uma turma"""
        if self.modo_rede:
            # Usa endpoint específico para adicionar aluno à turma
            success, msg = self.network_client.adicionar_aluno_a_turma(id_aluno, id_turma)
            return success
        else:
            self.db.adicionar_aluno_a_turma(id_aluno, id_turma)
            return True
    
    def atualizar_turma_aluno(self, id_aluno, id_turma):
        """Atualiza turma de um aluno"""
        if self.modo_rede:
            # Usa endpoint específico para atualizar turma do aluno
            success, msg = self.network_client.atualizar_turma_aluno(id_aluno, id_turma)
            return success
        else:
            self.db.atualizar_turma_aluno(id_aluno, id_turma)
            return True
    
    def atualizar_turma_alunos(self, ids_alunos, id_turma):
        """Atualiza turma de múltiplos alunos"""
        if self.modo_rede:
            for id_aluno in ids_alunos:
                self.atualizar_turma_aluno(id_aluno, id_turma)
            return True
        else:
            self.db.atualizar_turma_alunos(ids_alunos, id_turma)
            return True
    
    def excluir_turma(self, id_turma):
        """Exclui uma turma"""
        if self.modo_rede:
            success, msg = self.network_client.excluir_turma(id_turma)
            return success
        else:
            return self.db.excluir_turma(id_turma)
    
    # ===== CONSTANTES (para compatibilidade) =====
    
    @property
    def ARQUIVO_USUARIOS(self):
        return self.db.ARQUIVO_USUARIOS if not self.modo_rede else None
    
    @property
    def ARQUIVO_TURMAS(self):
        return self.db.ARQUIVO_TURMAS if not self.modo_rede else None
    
    @property
    def ARQUIVO_AULAS(self):
        return self.db.ARQUIVO_AULAS if not self.modo_rede else None
    
    @property
    def ARQUIVO_ATIVIDADES(self):
        return self.db.ARQUIVO_ATIVIDADES if not self.modo_rede else None
