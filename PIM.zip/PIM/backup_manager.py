"""
Módulo para gerenciar backups do sistema usando o executável C++
"""
import subprocess
import os
from pathlib import Path


class BackupManager:
    def __init__(self, caminho_executavel=None, diretorio_database=None):
        """
        Inicializa o gerenciador de backup
        
        Args:
            caminho_executavel: Caminho para backup_system.exe (opcional)
            diretorio_database: Caminho para a pasta database (opcional)
        """
        # Define o executável
        if caminho_executavel is None:
            self.executavel = Path(__file__).parent / "backup_system.exe"
        else:
            self.executavel = Path(caminho_executavel)
        
        # Define o diretório database
        if diretorio_database is None:
            self.diretorio_database = Path(__file__).parent / "database"
        else:
            self.diretorio_database = Path(diretorio_database)
    
    def verificar_executavel(self):
        """Verifica se o executável existe"""
        return self.executavel.exists()
    
    def compilar_cpp(self):
        """
        Tenta compilar o backup_system.cpp se o executável não existir
        Requer g++ instalado no sistema
        """
        cpp_file = Path(__file__).parent / "backup_system.cpp"
        
        if not cpp_file.exists():
            return False, "Arquivo backup_system.cpp não encontrado!"
        
        try:
            # Tenta compilar com g++
            resultado = subprocess.run(
                ["g++", str(cpp_file), "-o", str(self.executavel), "-std=c++17"],
                capture_output=True,
                text=True
            )
            
            if resultado.returncode == 0:
                return True, "Compilação bem-sucedida!"
            else:
                return False, f"Erro na compilação:\n{resultado.stderr}"
        
        except FileNotFoundError:
            return False, "g++ não encontrado. Instale MinGW ou outro compilador C++."
        except Exception as e:
            return False, f"Erro ao compilar: {str(e)}"
    
    def executar_backup_automatico(self):
        """
        Executa backup sem interação do usuário
        
        Returns:
            tuple: (sucesso, mensagem)
        """
        # Verifica se o executável existe
        if not self.verificar_executavel():
            # Tenta compilar
            sucesso_comp, msg_comp = self.compilar_cpp()
            if not sucesso_comp:
                return False, f"Executável não encontrado e falha ao compilar:\n{msg_comp}"
        
        try:
            # Executa o backup em modo automático
            # Passa o diretório database e o flag --auto
            resultado = subprocess.run(
                [str(self.executavel), str(self.diretorio_database), "--auto"],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='ignore'
            )
            
            sucesso = resultado.returncode == 0
            
            if sucesso:
                # Extrai informações do output
                output = resultado.stdout
                mensagem = "Backup realizado com sucesso!\n"
                
                # Tenta encontrar a linha com o local do backup
                for linha in output.split('\n'):
                    if 'Local do backup:' in linha:
                        mensagem += linha.strip()
                        break
                
                return True, mensagem
            else:
                return False, f"Backup falhou.\n{resultado.stdout}"
        
        except Exception as e:
            return False, f"Erro ao executar backup: {str(e)}"
    
    def executar_backup_interativo(self):
        """
        Abre janela do terminal para backup interativo
        
        Returns:
            tuple: (sucesso, mensagem)
        """
        # Verifica se o executável existe
        if not self.verificar_executavel():
            # Tenta compilar
            sucesso_comp, msg_comp = self.compilar_cpp()
            if not sucesso_comp:
                return False, f"Executável não encontrado e falha ao compilar:\n{msg_comp}"
        
        try:
            # Abre nova janela do console com o programa de backup
            # CREATE_NEW_CONSOLE abre em janela separada no Windows
            subprocess.Popen(
                [str(self.executavel), str(self.diretorio_database)],
                creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
            )
            return True, "Backup iniciado em nova janela"
        
        except Exception as e:
            return False, f"Erro ao executar backup: {str(e)}"
    
    def obter_informacoes(self):
        """
        Retorna informações sobre o sistema de backup
        
        Returns:
            dict: Informações do sistema
        """
        return {
            'executavel_existe': self.verificar_executavel(),
            'caminho_executavel': str(self.executavel),
            'diretorio_database': str(self.diretorio_database),
            'arquivos_backup': [
                'alunos.txt',
                'atividades.txt',
                'aulas.txt',
                'chamadas.txt',
                'notas.txt',
                'professores.txt',
                'turmas.txt',
                'usuarios.txt'
            ]
        }


# Função auxiliar para uso rápido
def fazer_backup_rapido():
    """Executa backup automaticamente (função auxiliar)"""
    backup = BackupManager()
    return backup.executar_backup_automatico()


if __name__ == "__main__":
    # Teste do módulo
    print("=== TESTE DO BACKUP MANAGER ===\n")
    
    backup = BackupManager()
    info = backup.obter_informacoes()
    
    print("Informações do sistema:")
    print(f"  Executável existe: {info['executavel_existe']}")
    print(f"  Caminho: {info['caminho_executavel']}")
    print(f"  Database: {info['diretorio_database']}")
    print(f"  Arquivos: {len(info['arquivos_backup'])}")
    
    print("\nTentando executar backup automático...")
    sucesso, msg = backup.executar_backup_automatico()
    
    if sucesso:
        print(f"✓ {msg}")
    else:
        print(f"✗ {msg}")
