"""
Script de teste para verificar salvamento de turmas
"""

import database as db
from models import Turma

# Inicializar arquivos
db.inicializar_arquivos()

print("=== TESTE DE SALVAMENTO DE TURMAS ===\n")

# Teste 1: Criar primeira turma
print("TESTE 1: Criando primeira turma...")
id1 = db.get_proximo_id(db.ARQUIVO_TURMAS)
turma1 = Turma(id=id1, nome_disciplina="Matemática", id_alunos=[])
db.salvar_turma(turma1)
print(f"Turma 1 criada: ID={id1}\n")

# Listar turmas
print("Turmas após teste 1:")
turmas = db.listar_turmas()
for t in turmas:
    print(f"  - {t}")
print()

# Teste 2: Criar segunda turma
print("TESTE 2: Criando segunda turma...")
id2 = db.get_proximo_id(db.ARQUIVO_TURMAS)
turma2 = Turma(id=id2, nome_disciplina="Português", id_alunos=[])
db.salvar_turma(turma2)
print(f"Turma 2 criada: ID={id2}\n")

# Listar turmas novamente
print("Turmas após teste 2:")
turmas = db.listar_turmas()
for t in turmas:
    print(f"  - {t}")
print()

# Teste 3: Criar terceira turma
print("TESTE 3: Criando terceira turma...")
id3 = db.get_proximo_id(db.ARQUIVO_TURMAS)
turma3 = Turma(id=id3, nome_disciplina="História", id_alunos=[])
db.salvar_turma(turma3)
print(f"Turma 3 criada: ID={id3}\n")

# Listar turmas final
print("Turmas após teste 3:")
turmas = db.listar_turmas()
for t in turmas:
    print(f"  - {t}")
print()

print(f"Total de turmas: {len(turmas)}")
print("\n=== FIM DOS TESTES ===")
