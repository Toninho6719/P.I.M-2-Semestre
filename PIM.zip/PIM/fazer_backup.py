"""
Script simples para fazer backup dos arquivos do sistema
Execute: python fazer_backup.py
"""
import os
import shutil
from pathlib import Path
from datetime import datetime


def fazer_backup():
    """Faz backup dos arquivos .txt para a área de trabalho"""
    
    # Diretório de origem (pasta database)
    source_dir = Path(__file__).parent / "database"
    
    # Diretório de destino (Área de Trabalho)
    desktop = Path.home() / "Desktop"
    timestamp = datetime.now().strftime("Backup_%Y%m%d_%H%M%S")
    backup_dir = desktop / timestamp
    
    # Lista de arquivos para backup
    arquivos = [
        "alunos.txt",
        "atividades.txt",
        "aulas.txt",
        "chamadas.txt",
        "notas.txt",
        "professores.txt",
        "turmas.txt",
        "usuarios.txt"
    ]
    
    print("=" * 60)
    print("           SISTEMA DE BACKUP - PIM ACADÊMICO")
    print("=" * 60)
    print()
    print(f"📁 Origem: {source_dir}")
    print(f"💾 Destino: {backup_dir}")
    print()
    
    # Cria pasta de backup
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        print(f"✓ Pasta de backup criada\n")
    except Exception as e:
        print(f"✗ Erro ao criar pasta: {e}")
        return False
    
    # Copia arquivos
    sucessos = 0
    falhas = 0
    
    print("Copiando arquivos:")
    print("-" * 60)
    
    for arquivo in arquivos:
        source_file = source_dir / arquivo
        dest_file = backup_dir / arquivo
        
        print(f"  {arquivo:20} ... ", end="")
        
        if source_file.exists():
            try:
                shutil.copy2(source_file, dest_file)
                print("✓ OK")
                sucessos += 1
            except Exception as e:
                print(f"✗ ERRO: {e}")
                falhas += 1
        else:
            print("⚠ NÃO ENCONTRADO")
            falhas += 1
    
    # Relatório
    print()
    print("=" * 60)
    print("                    RELATÓRIO")
    print("=" * 60)
    print(f"✓ Sucesso: {sucessos} arquivos")
    print(f"✗ Falhas:  {falhas} arquivos")
    print(f"📂 Local:  {backup_dir}")
    print("=" * 60)
    
    return falhas == 0


if __name__ == "__main__":
    try:
        sucesso = fazer_backup()
        print()
        if sucesso:
            print("✅ Backup concluído com sucesso!")
        else:
            print("⚠️  Backup concluído com alguns erros.")
        
        input("\nPressione Enter para sair...")
    except KeyboardInterrupt:
        print("\n\n❌ Backup cancelado pelo usuário.")
    except Exception as e:
        print(f"\n\n❌ Erro inesperado: {e}")
        input("\nPressione Enter para sair...")
